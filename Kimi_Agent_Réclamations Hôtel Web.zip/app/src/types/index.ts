// Types pour l'application Hôtel Réclamation

export interface Client {
  id: string;
  email: string;
  roomNumber: string;
  name: string;
  checkInDate: string;
  checkOutDate: string;
}

export interface Admin {
  id: string;
  username: string;
  password: string;
  name: string;
  role: 'superadmin' | 'admin' | 'manager';
  createdAt: string;
}

export type ComplaintStatus = 'pending' | 'in-progress' | 'resolved' | 'closed';
export type ComplaintPriority = 'low' | 'medium' | 'high' | 'urgent';

export interface StatusHistory {
  id: string;
  status: ComplaintStatus;
  changedBy: string;
  changedByRole: 'client' | 'admin' | 'system';
  changedAt: string;
  note?: string;
}

export interface Complaint {
  id: string;
  clientId: string;
  clientName: string;
  clientEmail: string;
  roomNumber: string;
  department: string;
  subDepartment: string;
  title: string;
  description: string;
  status: ComplaintStatus;
  priority: ComplaintPriority;
  createdAt: string;
  updatedAt: string;
  resolvedAt?: string;
  assignedTo?: string;
  notes: Note[];
  feedback?: Feedback;
  attachments: string[];
  statusHistory: StatusHistory[];
}

export interface Note {
  id: string;
  complaintId: string;
  author: string;
  authorRole: 'client' | 'admin' | 'system';
  content: string;
  createdAt: string;
}

export interface Feedback {
  id: string;
  complaintId: string;
  rating: number; // 1-5
  comment: string;
  createdAt: string;
}

export interface Department {
  id: string;
  name: string;
  icon: string;
  subDepartments: SubDepartment[];
  isActive: boolean;
}

export interface SubDepartment {
  id: string;
  name: string;
  description: string;
  isActive: boolean;
}

export interface AppConfig {
  hotelName: string;
  hotelLogo?: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  emailNotifications: boolean;
  notificationEmail: string;
  smsNotifications: boolean;
  whatsappNotifications: boolean;
  whatsappNumber: string;
  autoAssign: boolean;
  responseTimeHours: number;
  languages: string[];
  defaultLanguage: string;
}

export interface Stats {
  totalComplaints: number;
  pendingComplaints: number;
  inProgressComplaints: number;
  resolvedComplaints: number;
  closedComplaints: number;
  averageResolutionTime: number; // en heures
  satisfactionRate: number; // pourcentage
  complaintsByDepartment: Record<string, number>;
  complaintsByStatus: Record<string, number>;
  complaintsByPriority: Record<string, number>;
  dailyStats: DailyStat[];
}

export interface DailyStat {
  date: string;
  created: number;
  resolved: number;
}

export interface Notification {
  id: string;
  userId: string;
  userType: 'client' | 'admin';
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  isRead: boolean;
  createdAt: string;
  link?: string;
}

export type View = 
  | 'client-login' 
  | 'client-dashboard' 
  | 'client-new-complaint' 
  | 'client-track' 
  | 'client-feedback'
  | 'client-stats'
  | 'admin-login' 
  | 'admin-dashboard' 
  | 'admin-complaints' 
  | 'admin-stats' 
  | 'admin-config'
  | 'landing';
