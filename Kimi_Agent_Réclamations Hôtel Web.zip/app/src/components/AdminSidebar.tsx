import { useState } from 'react';
import type { View, Admin } from '@/types';
import { 
  MessageSquare, 
  LayoutDashboard, 
  List, 
  BarChart3, 
  Settings, 
  LogOut, 
  Bell,
  Menu,
  X,
  ChevronRight
} from 'lucide-react';
import { toast } from 'sonner';

interface AdminSidebarProps {
  admin: Admin | null;
  currentView: View;
  onNavigate: (view: View) => void;
  onLogout: () => void;
  unreadCount?: number;
}

const menuItems = [
  { id: 'admin-dashboard', label: 'Tableau de bord', icon: LayoutDashboard },
  { id: 'admin-complaints', label: 'Réclamations', icon: List, badge: 'unread' },
  { id: 'admin-stats', label: 'Statistiques', icon: BarChart3 },
  { id: 'admin-config', label: 'Configuration', icon: Settings },
];

export default function AdminSidebar({ 
  admin, 
  currentView, 
  onNavigate, 
  onLogout,
  unreadCount = 0 
}: AdminSidebarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleNavigate = (view: View) => {
    onNavigate(view);
    setIsMobileMenuOpen(false);
  };

  const isActive = (view: string) => currentView === view;

  return (
    <>
      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 bg-white shadow-sm z-50 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg gradient-hero flex items-center justify-center">
            <MessageSquare className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-gray-900">Admin</span>
        </div>
        <div className="flex items-center gap-2">
          <button 
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg relative"
            onClick={() => toast.info('Notifications', { description: `${unreadCount} nouvelles notifications` })}
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar - Desktop (Fixed) & Mobile (Slide) */}
      <aside 
        className={`
          fixed lg:fixed left-0 top-0 bottom-0 w-64 bg-white shadow-xl z-50
          transform transition-transform duration-300 ease-in-out
          lg:translate-x-0
          ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
      >
        {/* Logo */}
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg gradient-hero flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-gray-900 text-sm">Hôtel Réclamation</h1>
              <p className="text-xs text-gray-500">Espace Admin</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavigate(item.id as View)}
              className={`
                w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-200
                ${isActive(item.id)
                  ? 'bg-[#0075D5] text-white shadow-lg shadow-blue-500/30'
                  : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                }
              `}
            >
              <item.icon className={`w-5 h-5 ${isActive(item.id) ? 'text-white' : 'text-gray-400'}`} />
              <span className="font-medium">{item.label}</span>
              {item.badge && unreadCount > 0 && (
                <span className={`
                  ml-auto px-2 py-0.5 text-xs rounded-full
                  ${isActive(item.id) ? 'bg-white text-[#0075D5]' : 'bg-red-500 text-white'}
                `}>
                  {unreadCount}
                </span>
              )}
              {isActive(item.id) && <ChevronRight className="w-4 h-4 ml-auto" />}
            </button>
          ))}
        </nav>

        {/* User Section */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-100 bg-white">
          {admin && (
            <div className="flex items-center gap-3 mb-4 p-3 bg-gray-50 rounded-xl">
              <div className="w-10 h-10 rounded-full gradient-hero flex items-center justify-center text-white font-semibold">
                {admin.name.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-900 text-sm truncate">{admin.name}</p>
                <p className="text-xs text-gray-500 capitalize">{admin.role}</p>
              </div>
            </div>
          )}
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 text-red-600 hover:bg-red-50 rounded-xl transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Déconnexion</span>
          </button>
        </div>
      </aside>

      {/* Spacer for desktop */}
      <div className="hidden lg:block w-64 flex-shrink-0" />
    </>
  );
}
