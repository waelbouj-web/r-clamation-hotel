import { useState, useEffect } from 'react';
import type { View } from '@/types';
import { dataStore } from '@/store/dataStore';
import { Toaster } from '@/components/ui/sonner';

// Views
import LandingPage from '@/views/LandingPage';
import ClientLogin from '@/views/client/ClientLogin';
import ClientDashboard from '@/views/client/ClientDashboard';
import NewComplaint from '@/views/client/NewComplaint';
import TrackComplaints from '@/views/client/TrackComplaints';
import ClientFeedback from '@/views/client/ClientFeedback';
import ClientStats from '@/views/client/ClientStats';
import AdminLogin from '@/views/admin/AdminLogin';
import AdminDashboard from '@/views/admin/AdminDashboard';
import AdminComplaints from '@/views/admin/AdminComplaints';
import AdminStats from '@/views/admin/AdminStats';
import AdminConfig from '@/views/admin/AdminConfig';

function App() {
  const [currentView, setCurrentView] = useState<View>('landing');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Generate sample data for demo
    dataStore.generateSampleData();
    
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  const navigateTo = (view: View) => {
    setCurrentView(view);
    window.scrollTo(0, 0);
  };

  const renderView = () => {
    switch (currentView) {
      case 'landing':
        return <LandingPage onNavigate={navigateTo} />;
      case 'client-login':
        return <ClientLogin onNavigate={navigateTo} />;
      case 'client-dashboard':
        return <ClientDashboard onNavigate={navigateTo} />;
      case 'client-new-complaint':
        return <NewComplaint onNavigate={navigateTo} />;
      case 'client-track':
        return <TrackComplaints onNavigate={navigateTo} />;
      case 'client-feedback':
        return <ClientFeedback onNavigate={navigateTo} />;
      case 'client-stats':
        return <ClientStats onNavigate={navigateTo} />;
      case 'admin-login':
        return <AdminLogin onNavigate={navigateTo} />;
      case 'admin-dashboard':
        return <AdminDashboard onNavigate={navigateTo} />;
      case 'admin-complaints':
        return <AdminComplaints onNavigate={navigateTo} />;
      case 'admin-stats':
        return <AdminStats onNavigate={navigateTo} />;
      case 'admin-config':
        return <AdminConfig onNavigate={navigateTo} />;
      default:
        return <LandingPage onNavigate={navigateTo} />;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center gradient-hero">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <h2 className="text-white text-xl font-semibold">Chargement...</h2>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {renderView()}
      <Toaster position="top-right" richColors />
    </div>
  );
}

export default App;
