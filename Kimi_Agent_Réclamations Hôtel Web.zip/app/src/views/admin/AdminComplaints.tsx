import { useEffect, useState } from 'react';
import type { View, Admin, Complaint } from '@/types';
import { dataStore } from '@/store/dataStore';
import AdminSidebar from '@/components/AdminSidebar';
import { 
  Search, 
  Filter,
  Clock, 
  CheckCircle, 
  AlertCircle, 
  XCircle,
  MessageCircle,
  Calendar,
  Building2,
  Tag,
  Send,
  Loader2,
  Star,
  ChevronDown,
  User,
  MoreHorizontal,
  Edit3,
  CheckSquare,
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  History
} from 'lucide-react';
import { toast } from 'sonner';

interface AdminComplaintsProps {
  onNavigate: (view: View) => void;
}

export default function AdminComplaints({ onNavigate }: AdminComplaintsProps) {
  const [admin, setAdmin] = useState<Admin | null>(null);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [filteredComplaints, setFilteredComplaints] = useState<Complaint[]>([]);
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [newNote, setNewNote] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showStatusMenu, setShowStatusMenu] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    const currentAdmin = dataStore.getCurrentAdmin();
    if (!currentAdmin) {
      toast.error('Veuillez vous connecter');
      onNavigate('admin-login');
      return;
    }
    setAdmin(currentAdmin);
    loadComplaints();
  }, [onNavigate]);

  useEffect(() => {
    filterComplaints();
  }, [complaints, searchQuery, statusFilter, priorityFilter]);

  const loadComplaints = () => {
    const allComplaints = dataStore.getAllComplaints();
    setComplaints(allComplaints);
  };

  const filterComplaints = () => {
    let filtered = [...complaints];
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(c => 
        c.title.toLowerCase().includes(query) ||
        c.clientName.toLowerCase().includes(query) ||
        c.roomNumber.includes(query) ||
        c.department.toLowerCase().includes(query)
      );
    }
    
    if (statusFilter !== 'all') {
      filtered = filtered.filter(c => c.status === statusFilter);
    }

    if (priorityFilter !== 'all') {
      filtered = filtered.filter(c => c.priority === priorityFilter);
    }
    
    setFilteredComplaints(filtered);
    setCurrentPage(1);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-5 h-5" />;
      case 'in-progress':
        return <AlertCircle className="w-5 h-5" />;
      case 'resolved':
        return <CheckCircle className="w-5 h-5" />;
      case 'closed':
        return <XCircle className="w-5 h-5" />;
      default:
        return <Clock className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'in-progress':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'resolved':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'closed':
        return 'bg-gray-100 text-gray-700 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'pending':
        return 'En attente';
      case 'in-progress':
        return 'En cours';
      case 'resolved':
        return 'Résolue';
      case 'closed':
        return 'Fermée';
      default:
        return status;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return <span className="badge badge-urgent">Urgente</span>;
      case 'high':
        return <span className="badge badge-high">Haute</span>;
      case 'medium':
        return <span className="badge badge-medium">Moyenne</span>;
      case 'low':
        return <span className="badge badge-low">Basse</span>;
      default:
        return null;
    }
  };

  const handleUpdateStatus = async (newStatus: string) => {
    if (!selectedComplaint) return;

    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));

    dataStore.updateComplaintStatus(
      selectedComplaint.id, 
      newStatus as any, 
      admin?.name || 'Admin',
      'admin'
    );

    toast.success(`Statut mis à jour: ${getStatusLabel(newStatus)}`);
    loadComplaints();
    setSelectedComplaint(dataStore.getComplaintById(selectedComplaint.id) || null);
    setShowStatusMenu(false);
    setIsLoading(false);
  };

  const handleAddNote = async () => {
    if (!selectedComplaint || !newNote.trim()) return;

    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));

    dataStore.addNoteToComplaint(selectedComplaint.id, {
      author: admin?.name || 'Admin',
      authorRole: 'admin',
      content: newNote,
    });

    toast.success('Commentaire ajouté');
    setNewNote('');
    loadComplaints();
    setSelectedComplaint(dataStore.getComplaintById(selectedComplaint.id) || null);
    setIsLoading(false);
  };

  const handleLogout = () => {
    dataStore.logoutAdmin();
    toast.success('Déconnexion réussie');
    onNavigate('landing');
  };

  // Pagination
  const totalPages = Math.ceil(filteredComplaints.length / itemsPerPage);
  const paginatedComplaints = filteredComplaints.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  if (!admin) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <AdminSidebar 
        admin={admin}
        currentView="admin-complaints"
        onNavigate={onNavigate}
        onLogout={handleLogout}
      />

      {/* Main Content */}
      <main className="flex-1">
        {selectedComplaint ? (
          // Detail View
          <div className="min-h-screen bg-gray-50">
            {/* Header */}
            <header className="bg-white shadow-sm sticky top-0 lg:top-0 z-30 mt-16 lg:mt-0">
              <div className="px-4 sm:px-6 lg:px-8 py-4">
                <button
                  onClick={() => setSelectedComplaint(null)}
                  className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
                >
                  <ArrowLeft className="w-5 h-5" />
                  Retour à la liste
                </button>
              </div>
            </header>

            <div className="p-4 sm:p-6 lg:p-8 space-y-6">
              {/* Header Card */}
              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(selectedComplaint.status)}`}>
                        {getStatusIcon(selectedComplaint.status)}
                        {getStatusLabel(selectedComplaint.status)}
                      </span>
                      {getPriorityBadge(selectedComplaint.priority)}
                    </div>
                    <h2 className="text-xl font-bold text-gray-900">{selectedComplaint.title}</h2>
                  </div>
                  
                  {/* Status Update Dropdown */}
                  <div className="relative">
                    <button
                      onClick={() => setShowStatusMenu(!showStatusMenu)}
                      className="flex items-center gap-2 px-4 py-2 bg-[#0075D5] text-white rounded-lg hover:bg-[#0059A7] transition-colors"
                    >
                      <Edit3 className="w-4 h-4" />
                      Changer le statut
                      <ChevronDown className="w-4 h-4" />
                    </button>
                    
                    {showStatusMenu && (
                      <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-100 z-10">
                        {['pending', 'in-progress', 'resolved', 'closed'].map((status) => (
                          <button
                            key={status}
                            onClick={() => handleUpdateStatus(status)}
                            className="w-full flex items-center gap-2 px-4 py-2 hover:bg-gray-50 text-left first:rounded-t-lg last:rounded-b-lg"
                          >
                            {getStatusIcon(status)}
                            {getStatusLabel(status)}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="grid sm:grid-cols-3 gap-4 text-sm">
                  <div className="flex items-center gap-2 text-gray-600">
                    <User className="w-4 h-4" />
                    {selectedComplaint.clientName}
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Building2 className="w-4 h-4" />
                    Ch. {selectedComplaint.roomNumber}
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Tag className="w-4 h-4" />
                    {selectedComplaint.department} • {selectedComplaint.subDepartment}
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Calendar className="w-4 h-4" />
                    {new Date(selectedComplaint.createdAt).toLocaleString('fr-FR')}
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <MoreHorizontal className="w-4 h-4" />
                    #{selectedComplaint.id.split('-')[1]}
                  </div>
                  {selectedComplaint.assignedTo && (
                    <div className="flex items-center gap-2 text-gray-600">
                      <CheckSquare className="w-4 h-4" />
                      Assigné à: {selectedComplaint.assignedTo}
                    </div>
                  )}
                </div>
              </div>

              {/* Description */}
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h3 className="font-semibold text-gray-900 mb-3">Description</h3>
                <p className="text-gray-700 whitespace-pre-wrap">{selectedComplaint.description}</p>
              </div>

              {/* Status History */}
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <History className="w-5 h-5 text-[#0075D5]" />
                  Historique des traitements ({selectedComplaint.statusHistory?.length || 0})
                </h3>

                <div className="space-y-3">
                  {(selectedComplaint.statusHistory || []).length === 0 ? (
                    <p className="text-gray-500 text-center py-4">
                      Aucun historique disponible.
                    </p>
                  ) : (
                    (selectedComplaint.statusHistory || []).map((history, index) => (
                      <div
                        key={history.id}
                        className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg"
                      >
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${getStatusColor(history.status)}`}>
                          {getStatusIcon(history.status)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium text-gray-900">
                              {getStatusLabel(history.status)}
                            </span>
                            <span className="text-xs text-gray-500">
                              {new Date(history.changedAt).toLocaleString('fr-FR')}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600 mb-1">{history.note}</p>
                          <p className="text-xs text-gray-400">
                            Par: {history.changedBy} ({history.changedByRole === 'admin' ? 'Admin' : history.changedByRole === 'client' ? 'Client' : 'Système'})
                          </p>
                        </div>
                        {index === 0 && (
                          <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
                            Dernier
                          </span>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Feedback if exists */}
              {selectedComplaint.feedback && (
                <div className="bg-green-50 rounded-xl p-6 border border-green-100">
                  <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                    <Star className="w-5 h-5 text-green-600" />
                    Avis du client
                  </h3>
                  <div className="flex items-center gap-2 mb-2">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-5 h-5 ${
                          i < selectedComplaint.feedback!.rating
                            ? 'fill-yellow-400 text-yellow-400'
                            : 'text-gray-300'
                        }`}
                      />
                    ))}
                    <span className="text-sm text-gray-500 ml-2">
                      {new Date(selectedComplaint.feedback.createdAt).toLocaleDateString('fr-FR')}
                    </span>
                  </div>
                  {selectedComplaint.feedback.comment && (
                    <p className="text-gray-700">{selectedComplaint.feedback.comment}</p>
                  )}
                </div>
              )}

              {/* Notes */}
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <MessageCircle className="w-5 h-5" />
                  Commentaires ({selectedComplaint.notes.length})
                </h3>

                <div className="space-y-4 mb-6">
                  {selectedComplaint.notes.length === 0 ? (
                    <p className="text-gray-500 text-center py-4">
                      Aucun commentaire pour le moment.
                    </p>
                  ) : (
                    selectedComplaint.notes.map((note) => (
                      <div
                        key={note.id}
                        className={`p-4 rounded-lg ${
                          note.authorRole === 'admin'
                            ? 'bg-blue-50 ml-8'
                            : 'bg-gray-50 mr-8'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-gray-900">{note.author}</span>
                          <span className="text-xs text-gray-500">
                            {new Date(note.createdAt).toLocaleString('fr-FR')}
                          </span>
                        </div>
                        <p className="text-gray-700">{note.content}</p>
                      </div>
                    ))
                  )}
                </div>

                {/* Add Note */}
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    placeholder="Ajouter un commentaire..."
                    className="flex-1 input-field"
                    onKeyPress={(e) => e.key === 'Enter' && handleAddNote()}
                  />
                  <button
                    onClick={handleAddNote}
                    disabled={isLoading || !newNote.trim()}
                    className="btn-primary px-4 disabled:opacity-50"
                  >
                    {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          // List View
          <>
            {/* Header */}
            <header className="bg-white shadow-sm sticky top-0 lg:top-0 z-30 mt-16 lg:mt-0">
              <div className="px-4 sm:px-6 lg:px-8 py-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">Gestion des réclamations</h2>
                    <p className="text-gray-600">{filteredComplaints.length} réclamation(s)</p>
                  </div>
                </div>
              </div>
            </header>

            <div className="p-4 sm:p-6 lg:p-8 space-y-6">
              {/* Filters */}
              <div className="bg-white rounded-xl shadow-sm p-4">
                <div className="flex flex-wrap gap-4">
                  <div className="flex-1 min-w-[200px]">
                    <div className="relative">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Rechercher par titre, client, chambre..."
                        className="input-field pl-12"
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Filter className="w-5 h-5 text-gray-400" />
                    <select
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      className="input-field py-2.5"
                    >
                      <option value="all">Tous les statuts</option>
                      <option value="pending">En attente</option>
                      <option value="in-progress">En cours</option>
                      <option value="resolved">Résolues</option>
                      <option value="closed">Fermées</option>
                    </select>
                  </div>
                  <div className="flex items-center gap-2">
                    <select
                      value={priorityFilter}
                      onChange={(e) => setPriorityFilter(e.target.value)}
                      className="input-field py-2.5"
                    >
                      <option value="all">Toutes priorités</option>
                      <option value="urgent">Urgente</option>
                      <option value="high">Haute</option>
                      <option value="medium">Moyenne</option>
                      <option value="low">Basse</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Complaints List */}
              <div className="space-y-3">
                {paginatedComplaints.length === 0 ? (
                  <div className="bg-white rounded-xl shadow-sm p-12 text-center">
                    <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-6">
                      <Search className="w-10 h-10 text-gray-400" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      Aucune réclamation trouvée
                    </h3>
                    <p className="text-gray-600">
                      Essayez de modifier vos critères de recherche.
                    </p>
                  </div>
                ) : (
                  paginatedComplaints.map((complaint, index) => (
                    <div
                      key={complaint.id}
                      className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-all cursor-pointer animate-slide-up"
                      style={{ animationDelay: `${index * 50}ms` }}
                      onClick={() => setSelectedComplaint(complaint)}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusColor(complaint.status)}`}>
                              {getStatusIcon(complaint.status)}
                              {getStatusLabel(complaint.status)}
                            </span>
                            {getPriorityBadge(complaint.priority)}
                            {complaint.feedback && (
                              <span className="inline-flex items-center gap-1 text-xs text-green-600">
                                <Star className="w-3 h-3 fill-current" />
                                Avis reçu
                              </span>
                            )}
                          </div>
                          <h3 className="font-semibold text-gray-900 mb-1">{complaint.title}</h3>
                          <p className="text-sm text-gray-500 line-clamp-2">{complaint.description}</p>
                          <div className="flex items-center gap-4 mt-3 text-xs text-gray-400">
                            <span className="flex items-center gap-1">
                              <User className="w-3 h-3" />
                              {complaint.clientName}
                            </span>
                            <span className="flex items-center gap-1">
                              <Building2 className="w-3 h-3" />
                              Ch. {complaint.roomNumber}
                            </span>
                            <span>{complaint.department}</span>
                            <span>•</span>
                            <span>{new Date(complaint.createdAt).toLocaleDateString('fr-FR')}</span>
                            <span>•</span>
                            <span className="flex items-center gap-1">
                              <MessageCircle className="w-3 h-3" />
                              {complaint.notes.length}
                            </span>
                          </div>
                        </div>
                        <ChevronDown className="w-5 h-5 text-gray-400" />
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2">
                  <button
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    disabled={currentPage === 1}
                    className="p-2 rounded-lg bg-white shadow-sm disabled:opacity-50 hover:bg-gray-50"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <span className="px-4 py-2 bg-white rounded-lg shadow-sm">
                    Page {currentPage} sur {totalPages}
                  </span>
                  <button
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                    disabled={currentPage === totalPages}
                    className="p-2 rounded-lg bg-white shadow-sm disabled:opacity-50 hover:bg-gray-50"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              )}
            </div>
          </>
        )}
      </main>
    </div>
  );
}
