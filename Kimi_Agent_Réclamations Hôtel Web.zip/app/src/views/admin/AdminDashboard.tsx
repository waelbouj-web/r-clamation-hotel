import { useEffect, useState } from 'react';
import type { View, Admin, Complaint, Stats } from '@/types';
import { dataStore } from '@/store/dataStore';
import AdminSidebar from '@/components/AdminSidebar';
import { 
  Clock,
  CheckCircle,
  AlertCircle,
  XCircle,
  TrendingUp,
  TrendingDown,
  ChevronRight,
  Star,
  MessageSquare,
  Users,
  Timer
} from 'lucide-react';
import { toast } from 'sonner';

interface AdminDashboardProps {
  onNavigate: (view: View) => void;
}

export default function AdminDashboard({ onNavigate }: AdminDashboardProps) {
  const [admin, setAdmin] = useState<Admin | null>(null);
  const [stats, setStats] = useState<Stats | null>(null);
  const [recentComplaints, setRecentComplaints] = useState<Complaint[]>([]);
  const [unreadNotifications] = useState(3);

  useEffect(() => {
    const currentAdmin = dataStore.getCurrentAdmin();
    if (!currentAdmin) {
      toast.error('Veuillez vous connecter');
      onNavigate('admin-login');
      return;
    }
    setAdmin(currentAdmin);
    
    const allStats = dataStore.getStats();
    setStats(allStats);
    
    const allComplaints = dataStore.getAllComplaints();
    setRecentComplaints(allComplaints.slice(0, 5));
  }, [onNavigate]);

  const handleLogout = () => {
    dataStore.logoutAdmin();
    toast.success('Déconnexion réussie');
    onNavigate('landing');
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-5 h-5" />;
      case 'in-progress':
        return <AlertCircle className="w-5 h-5" />;
      case 'resolved':
        return <CheckCircle className="w-5 h-5" />;
      case 'closed':
        return <XCircle className="w-5 h-5" />;
      default:
        return <Clock className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'in-progress':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'resolved':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'closed':
        return 'bg-gray-100 text-gray-700 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'pending':
        return 'En attente';
      case 'in-progress':
        return 'En cours';
      case 'resolved':
        return 'Résolue';
      case 'closed':
        return 'Fermée';
      default:
        return status;
    }
  };

  if (!admin || !stats) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <AdminSidebar 
        admin={admin}
        currentView="admin-dashboard"
        onNavigate={onNavigate}
        onLogout={handleLogout}
        unreadCount={unreadNotifications}
      />

      {/* Main Content */}
      <main className="flex-1 lg:ml-0">
        {/* Top Header */}
        <header className="bg-white shadow-sm sticky top-0 lg:top-0 z-30 mt-16 lg:mt-0">
          <div className="px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Tableau de bord</h2>
                <p className="text-gray-600">Bienvenue, {admin.name}</p>
              </div>
              <div className="hidden sm:flex items-center gap-3">
                <div className="px-4 py-2 bg-green-50 text-green-700 rounded-lg text-sm font-medium">
                  En ligne
                </div>
              </div>
            </div>
          </div>
        </header>

        <div className="p-4 sm:p-6 lg:p-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {[
              { 
                label: 'Total', 
                value: stats.totalComplaints, 
                icon: MessageSquare, 
                color: 'bg-blue-500',
                trend: null
              },
              { 
                label: 'En attente', 
                value: stats.pendingComplaints, 
                icon: Clock, 
                color: 'bg-yellow-500',
                trend: stats.pendingComplaints > 5 ? 'up' : null
              },
              { 
                label: 'En cours', 
                value: stats.inProgressComplaints, 
                icon: AlertCircle, 
                color: 'bg-orange-500',
                trend: null
              },
              { 
                label: 'Résolues', 
                value: stats.resolvedComplaints, 
                icon: CheckCircle, 
                color: 'bg-green-500',
                trend: 'up'
              },
            ].map((stat, index) => (
              <button
                key={index}
                onClick={() => onNavigate('admin-complaints')}
                className="bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 text-left group"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className={`w-12 h-12 rounded-xl ${stat.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex items-end gap-2">
                  <div className="text-3xl font-bold text-gray-900">{stat.value}</div>
                  {stat.trend && (
                    stat.trend === 'up' ? (
                      <TrendingUp className="w-5 h-5 text-green-500 mb-1" />
                    ) : (
                      <TrendingDown className="w-5 h-5 text-red-500 mb-1" />
                    )
                  )}
                </div>
                <div className="text-sm text-gray-500">{stat.label}</div>
              </button>
            ))}
          </div>

          {/* Performance Cards */}
          <div className="grid lg:grid-cols-3 gap-6 mb-8">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white">
              <div className="flex items-center gap-3 mb-4">
                <Users className="w-8 h-8" />
                <h4 className="font-semibold">Taux de résolution</h4>
              </div>
              <div className="text-4xl font-bold mb-2">
                {Math.round((stats.resolvedComplaints / Math.max(stats.totalComplaints, 1)) * 100)}%
              </div>
              <p className="text-blue-100 text-sm">
                {stats.resolvedComplaints} sur {stats.totalComplaints} réclamations
              </p>
            </div>

            <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white">
              <div className="flex items-center gap-3 mb-4">
                <Star className="w-8 h-8" />
                <h4 className="font-semibold">Satisfaction client</h4>
              </div>
              <div className="text-4xl font-bold mb-2">
                {stats.satisfactionRate.toFixed(0)}%
              </div>
              <p className="text-green-100 text-sm">
                Note moyenne: {(stats.satisfactionRate / 20).toFixed(1)}/5
              </p>
            </div>

            <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white">
              <div className="flex items-center gap-3 mb-4">
                <Timer className="w-8 h-8" />
                <h4 className="font-semibold">Temps moyen</h4>
              </div>
              <div className="text-4xl font-bold mb-2">
                {stats.averageResolutionTime.toFixed(1)}h
              </div>
              <p className="text-purple-100 text-sm">
                Objectif: 24h
              </p>
            </div>
          </div>

          {/* Recent Complaints */}
          <div className="bg-white rounded-xl shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
              <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-[#0075D5]" />
                Réclamations récentes
              </h3>
              <button
                onClick={() => onNavigate('admin-complaints')}
                className="text-sm text-[#0075D5] hover:underline flex items-center gap-1"
              >
                Voir tout
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
            
            {recentComplaints.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-gray-500">Aucune réclamation pour le moment.</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {recentComplaints.map((complaint) => (
                  <div
                    key={complaint.id}
                    onClick={() => onNavigate('admin-complaints')}
                    className="px-6 py-4 hover:bg-gray-50 transition-colors cursor-pointer flex items-center justify-between"
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getStatusColor(complaint.status)}`}>
                        {getStatusIcon(complaint.status)}
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">{complaint.title}</h4>
                        <p className="text-sm text-gray-500">
                          {complaint.clientName} • Ch. {complaint.roomNumber} • {complaint.department}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(complaint.status)}`}>
                        {getStatusLabel(complaint.status)}
                      </span>
                      <span className="text-sm text-gray-400">
                        {new Date(complaint.createdAt).toLocaleDateString('fr-FR')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
