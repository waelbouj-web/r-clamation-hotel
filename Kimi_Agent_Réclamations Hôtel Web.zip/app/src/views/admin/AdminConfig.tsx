import { useEffect, useState } from 'react';
import type { View, Admin, Department, AppConfig } from '@/types';
import { dataStore } from '@/store/dataStore';
import AdminSidebar from '@/components/AdminSidebar';
import { 
  Settings, 
  Building2,
  Bell,
  Users,
  Plus,
  Trash2,
  Check,
  X,
  Save,
  Loader2,
  Mail,
  Clock,
  Lock,
  Eye,
  EyeOff,
  UserPlus,
  Smartphone
} from 'lucide-react';
import { toast } from 'sonner';

interface AdminConfigProps {
  onNavigate: (view: View) => void;
}

export default function AdminConfig({ onNavigate }: AdminConfigProps) {
  const [admin, setAdmin] = useState<Admin | null>(null);
  const [config, setConfig] = useState<AppConfig | null>(null);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [activeTab, setActiveTab] = useState<'general' | 'departments' | 'admins' | 'notifications'>('general');
  const [isLoading, setIsLoading] = useState(false);
  const [newDeptName, setNewDeptName] = useState('');
  const [showAddDept, setShowAddDept] = useState(false);

  // Admin form state
  const [showAddAdmin, setShowAddAdmin] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<string | null>(null);
  const [newAdmin, setNewAdmin] = useState({
    name: '',
    username: '',
    password: '',
    role: 'admin' as 'admin' | 'manager' | 'superadmin'
  });
  const [editPassword, setEditPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    const currentAdmin = dataStore.getCurrentAdmin();
    if (!currentAdmin) {
      toast.error('Veuillez vous connecter');
      onNavigate('admin-login');
      return;
    }
    setAdmin(currentAdmin);
    
    setConfig(dataStore.getConfig());
    setDepartments(dataStore.getAllDepartments());
    setAdmins(dataStore.getAllAdmins());
  }, [onNavigate]);

  const handleSaveConfig = async () => {
    if (!config) return;
    
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    
    dataStore.updateConfig(config);
    toast.success('Configuration sauvegardée');
    setIsLoading(false);
  };

  const handleToggleDept = (deptId: string) => {
    const dept = departments.find(d => d.id === deptId);
    if (dept) {
      dataStore.updateDepartment(deptId, { isActive: !dept.isActive });
      setDepartments(dataStore.getAllDepartments());
      toast.success(`${dept.name} ${dept.isActive ? 'désactivé' : 'activé'}`);
    }
  };

  const handleDeleteDept = (deptId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce département ?')) {
      dataStore.deleteDepartment(deptId);
      setDepartments(dataStore.getAllDepartments());
      toast.success('Département supprimé');
    }
  };

  const handleAddDept = () => {
    if (!newDeptName.trim()) return;
    
    dataStore.createDepartment({
      name: newDeptName,
      icon: 'Building2',
      subDepartments: [],
      isActive: true,
    });
    
    setDepartments(dataStore.getAllDepartments());
    setNewDeptName('');
    setShowAddDept(false);
    toast.success('Département ajouté');
  };

  const handleAddAdmin = () => {
    if (!newAdmin.name || !newAdmin.username || !newAdmin.password) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    dataStore.createAdmin({
      username: newAdmin.username,
      password: newAdmin.password,
      name: newAdmin.name,
      role: newAdmin.role,
      createdAt: new Date().toISOString(),
    });

    setAdmins(dataStore.getAllAdmins());
    setNewAdmin({ name: '', username: '', password: '', role: 'admin' });
    setShowAddAdmin(false);
    toast.success('Administrateur ajouté avec succès');
  };

  const handleUpdateAdminPassword = (adminId: string) => {
    if (!editPassword) {
      toast.error('Veuillez entrer un mot de passe');
      return;
    }

    // Update password in dataStore
    const adminList = dataStore.getAllAdmins();
    const targetAdmin = adminList.find(a => a.id === adminId);
    if (targetAdmin) {
      targetAdmin.password = editPassword;
      toast.success(`Mot de passe de ${targetAdmin.name} mis à jour`);
    }

    setEditingAdmin(null);
    setEditPassword('');
  };

  const handleDeleteAdmin = (adminId: string) => {
    if (adminId === admin?.id) {
      toast.error('Vous ne pouvez pas supprimer votre propre compte');
      return;
    }
    
    if (confirm('Êtes-vous sûr de vouloir supprimer cet administrateur ?')) {
      dataStore.deleteAdmin(adminId);
      setAdmins(dataStore.getAllAdmins());
      toast.success('Administrateur supprimé');
    }
  };

  const handleLogout = () => {
    dataStore.logoutAdmin();
    toast.success('Déconnexion réussie');
    onNavigate('landing');
  };

  if (!admin || !config) return null;

  const isSuperAdmin = admin.role === 'superadmin';

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <AdminSidebar 
        admin={admin}
        currentView="admin-config"
        onNavigate={onNavigate}
        onLogout={handleLogout}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* Header */}
        <header className="bg-white shadow-sm sticky top-0 lg:top-0 z-30 mt-16 lg:mt-0">
          <div className="px-4 sm:px-6 lg:px-8 py-4">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Configuration</h2>
              <p className="text-gray-600">Paramètres du système</p>
            </div>
          </div>
        </header>

        <div className="p-4 sm:p-6 lg:p-8">
          {/* Tabs */}
          <div className="flex flex-wrap gap-2 mb-8">
            {[
              { id: 'general', label: 'Général', icon: Settings },
              { id: 'departments', label: 'Départements', icon: Building2 },
              { id: 'admins', label: 'Administrateurs', icon: Users },
              { id: 'notifications', label: 'Notifications', icon: Bell },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-[#0075D5] text-white shadow-lg shadow-blue-500/30'
                    : 'bg-white text-gray-600 hover:bg-gray-100'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>

          {/* General Settings */}
          {activeTab === 'general' && (
            <div className="bg-white rounded-xl shadow-sm p-6 animate-fade-in max-w-2xl">
              <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <Settings className="w-5 h-5 text-[#0075D5]" />
                Paramètres généraux
              </h2>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nom de l'hôtel
                  </label>
                  <input
                    type="text"
                    value={config.hotelName}
                    onChange={(e) => setConfig({ ...config, hotelName: e.target.value })}
                    className="input-field"
                  />
                </div>

                <div className="grid sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Couleur principale
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="color"
                        value={config.primaryColor}
                        onChange={(e) => setConfig({ ...config, primaryColor: e.target.value })}
                        className="w-12 h-12 rounded-lg cursor-pointer border-2 border-gray-200"
                      />
                      <span className="text-sm text-gray-600 font-mono">{config.primaryColor}</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Couleur secondaire
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="color"
                        value={config.secondaryColor}
                        onChange={(e) => setConfig({ ...config, secondaryColor: e.target.value })}
                        className="w-12 h-12 rounded-lg cursor-pointer border-2 border-gray-200"
                      />
                      <span className="text-sm text-gray-600 font-mono">{config.secondaryColor}</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Couleur d'accent
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="color"
                        value={config.accentColor}
                        onChange={(e) => setConfig({ ...config, accentColor: e.target.value })}
                        className="w-12 h-12 rounded-lg cursor-pointer border-2 border-gray-200"
                      />
                      <span className="text-sm text-gray-600 font-mono">{config.accentColor}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Langue par défaut
                  </label>
                  <select
                    value={config.defaultLanguage}
                    onChange={(e) => setConfig({ ...config, defaultLanguage: e.target.value })}
                    className="input-field"
                  >
                    <option value="fr">Français</option>
                    <option value="en">English</option>
                    <option value="es">Español</option>
                    <option value="de">Deutsch</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Temps de réponse cible (heures)
                  </label>
                  <input
                    type="number"
                    value={config.responseTimeHours}
                    onChange={(e) => setConfig({ ...config, responseTimeHours: parseInt(e.target.value) })}
                    className="input-field"
                    min={1}
                    max={72}
                  />
                </div>

                <button
                  onClick={handleSaveConfig}
                  disabled={isLoading}
                  className="btn-primary flex items-center gap-2 disabled:opacity-50"
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <Save className="w-5 h-5" />
                  )}
                  Sauvegarder les modifications
                </button>
              </div>
            </div>
          )}

          {/* Departments */}
          {activeTab === 'departments' && (
            <div className="bg-white rounded-xl shadow-sm p-6 animate-fade-in max-w-2xl">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-[#0075D5]" />
                  Gestion des départements
                </h2>
                <button
                  onClick={() => setShowAddDept(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-[#0075D5] text-white rounded-lg hover:bg-[#0059A7] transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  Ajouter
                </button>
              </div>

              {showAddDept && (
                <div className="mb-6 p-4 bg-gray-50 rounded-xl flex gap-3">
                  <input
                    type="text"
                    value={newDeptName}
                    onChange={(e) => setNewDeptName(e.target.value)}
                    placeholder="Nom du département"
                    className="flex-1 input-field"
                    onKeyPress={(e) => e.key === 'Enter' && handleAddDept()}
                  />
                  <button
                    onClick={handleAddDept}
                    className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                  >
                    <Check className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => {
                      setShowAddDept(false);
                      setNewDeptName('');
                    }}
                    className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              )}

              <div className="space-y-3">
                {departments.map((dept) => (
                  <div
                    key={dept.id}
                    className={`flex items-center justify-between p-4 rounded-xl border ${
                      dept.isActive ? 'bg-white border-gray-200' : 'bg-gray-50 border-gray-100'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${dept.isActive ? 'bg-green-500' : 'bg-gray-300'}`} />
                      <span className={`font-medium ${dept.isActive ? 'text-gray-900' : 'text-gray-500'}`}>
                        {dept.name}
                      </span>
                      <span className="text-sm text-gray-400">
                        ({dept.subDepartments.length} sous-catégories)
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleToggleDept(dept.id)}
                        className={`p-2 rounded-lg transition-colors ${
                          dept.isActive
                            ? 'text-green-600 hover:bg-green-50'
                            : 'text-gray-400 hover:bg-gray-100'
                        }`}
                        title={dept.isActive ? 'Désactiver' : 'Activer'}
                      >
                        {dept.isActive ? <Check className="w-5 h-5" /> : <X className="w-5 h-5" />}
                      </button>
                      <button
                        onClick={() => handleDeleteDept(dept.id)}
                        className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                        title="Supprimer"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Admins */}
          {activeTab === 'admins' && (
            <div className="bg-white rounded-xl shadow-sm p-6 animate-fade-in max-w-2xl">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#0075D5]" />
                  Gestion des administrateurs
                </h2>
                {isSuperAdmin && (
                  <button
                    onClick={() => setShowAddAdmin(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-[#0075D5] text-white rounded-lg hover:bg-[#0059A7] transition-colors"
                  >
                    <UserPlus className="w-4 h-4" />
                    Ajouter
                  </button>
                )}
              </div>

              {!isSuperAdmin && (
                <div className="mb-6 p-4 bg-yellow-50 rounded-xl text-sm text-yellow-800">
                  Seuls les super administrateurs peuvent gérer les comptes administrateurs.
                </div>
              )}

              {/* Add Admin Form */}
              {showAddAdmin && isSuperAdmin && (
                <div className="mb-6 p-4 bg-gray-50 rounded-xl space-y-4">
                  <h3 className="font-semibold text-gray-900">Nouvel administrateur</h3>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <input
                      type="text"
                      value={newAdmin.name}
                      onChange={(e) => setNewAdmin({ ...newAdmin, name: e.target.value })}
                      placeholder="Nom complet"
                      className="input-field"
                    />
                    <input
                      type="text"
                      value={newAdmin.username}
                      onChange={(e) => setNewAdmin({ ...newAdmin, username: e.target.value })}
                      placeholder="Nom d'utilisateur"
                      className="input-field"
                    />
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={newAdmin.password}
                        onChange={(e) => setNewAdmin({ ...newAdmin, password: e.target.value })}
                        placeholder="Mot de passe"
                        className="input-field pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <select
                      value={newAdmin.role}
                      onChange={(e) => setNewAdmin({ ...newAdmin, role: e.target.value as any })}
                      className="input-field"
                    >
                      <option value="admin">Administrateur</option>
                      <option value="manager">Manager</option>
                      <option value="superadmin">Super Admin</option>
                    </select>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={handleAddAdmin}
                      className="flex-1 btn-primary"
                    >
                      Créer l'administrateur
                    </button>
                    <button
                      onClick={() => {
                        setShowAddAdmin(false);
                        setNewAdmin({ name: '', username: '', password: '', role: 'admin' });
                      }}
                      className="px-4 py-2 border-2 border-gray-200 rounded-lg text-gray-600 hover:bg-gray-100"
                    >
                      Annuler
                    </button>
                  </div>
                </div>
              )}

              {/* Admin List */}
              <div className="space-y-3">
                {admins.map((a) => (
                  <div
                    key={a.id}
                    className="p-4 bg-white rounded-xl border border-gray-200"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full gradient-hero flex items-center justify-center text-white font-semibold">
                          {a.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-medium text-gray-900">{a.name}</div>
                          <div className="text-sm text-gray-500">
                            {a.username} • <span className="capitalize">{a.role}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {isSuperAdmin && a.id !== admin.id && (
                          <>
                            <button
                              onClick={() => setEditingAdmin(editingAdmin === a.id ? null : a.id)}
                              className="p-2 text-[#0075D5] hover:bg-blue-50 rounded-lg transition-colors"
                              title="Modifier le mot de passe"
                            >
                              <Lock className="w-5 h-5" />
                            </button>
                            <button
                              onClick={() => handleDeleteAdmin(a.id)}
                              className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                              title="Supprimer"
                            >
                              <Trash2 className="w-5 h-5" />
                            </button>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Edit Password Form */}
                    {editingAdmin === a.id && (
                      <div className="mt-4 pt-4 border-t border-gray-100">
                        <div className="flex gap-3">
                          <div className="relative flex-1">
                            <input
                              type={showPassword ? 'text' : 'password'}
                              value={editPassword}
                              onChange={(e) => setEditPassword(e.target.value)}
                              placeholder="Nouveau mot de passe"
                              className="input-field pr-10"
                            />
                            <button
                              type="button"
                              onClick={() => setShowPassword(!showPassword)}
                              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                            >
                              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                          </div>
                          <button
                            onClick={() => handleUpdateAdminPassword(a.id)}
                            className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600"
                          >
                            <Check className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => {
                              setEditingAdmin(null);
                              setEditPassword('');
                            }}
                            className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
                          >
                            <X className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Notifications */}
          {activeTab === 'notifications' && (
            <div className="bg-white rounded-xl shadow-sm p-6 animate-fade-in max-w-2xl">
              <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <Bell className="w-5 h-5 text-[#0075D5]" />
                Paramètres de notification
              </h2>

              <div className="space-y-4">
                {/* Email Notifications */}
                <div className="p-4 bg-gray-50 rounded-xl">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Mail className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">Notifications par email</div>
                        <div className="text-sm text-gray-500">
                          Recevoir un email pour chaque nouvelle réclamation
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => setConfig({ ...config, emailNotifications: !config.emailNotifications })}
                      className={`w-14 h-8 rounded-full transition-colors relative ${
                        config.emailNotifications ? 'bg-[#0075D5]' : 'bg-gray-300'
                      }`}
                    >
                      <div
                        className={`w-6 h-6 bg-white rounded-full absolute top-1 transition-all ${
                          config.emailNotifications ? 'left-7' : 'left-1'
                        }`}
                      />
                    </button>
                  </div>
                  
                  {config.emailNotifications && (
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Adresse email de notification
                      </label>
                      <input
                        type="email"
                        value={config.notificationEmail}
                        onChange={(e) => setConfig({ ...config, notificationEmail: e.target.value })}
                        placeholder="ex: notifications@hotel.com"
                        className="input-field"
                      />
                    </div>
                  )}
                </div>

                {/* WhatsApp Notifications */}
                <div className="p-4 bg-gray-50 rounded-xl">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <Smartphone className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">Notifications WhatsApp</div>
                        <div className="text-sm text-gray-500">
                          Recevoir des alertes sur WhatsApp
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => setConfig({ ...config, whatsappNotifications: !config.whatsappNotifications })}
                      className={`w-14 h-8 rounded-full transition-colors relative ${
                        config.whatsappNotifications ? 'bg-[#0075D5]' : 'bg-gray-300'
                      }`}
                    >
                      <div
                        className={`w-6 h-6 bg-white rounded-full absolute top-1 transition-all ${
                          config.whatsappNotifications ? 'left-7' : 'left-1'
                        }`}
                      />
                    </button>
                  </div>
                  
                  {config.whatsappNotifications && (
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Numéro WhatsApp
                      </label>
                      <input
                        type="tel"
                        value={config.whatsappNumber}
                        onChange={(e) => setConfig({ ...config, whatsappNumber: e.target.value })}
                        placeholder="ex: 00216 XX XXX XXX"
                        className="input-field"
                      />
                      <p className="text-xs text-gray-500 mt-2">
                        Format international recommandé: 00216 XX XXX XXX
                      </p>
                    </div>
                  )}
                </div>

                {/* Auto Assign */}
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <Clock className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">Assignation automatique</div>
                      <div className="text-sm text-gray-500">
                        Assigner automatiquement les réclamations aux administrateurs
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setConfig({ ...config, autoAssign: !config.autoAssign })}
                    className={`w-14 h-8 rounded-full transition-colors relative ${
                      config.autoAssign ? 'bg-[#0075D5]' : 'bg-gray-gray-300'
                    }`}
                  >
                    <div
                      className={`w-6 h-6 bg-white rounded-full absolute top-1 transition-all ${
                        config.autoAssign ? 'left-7' : 'left-1'
                      }`}
                    />
                  </button>
                </div>

                <button
                  onClick={handleSaveConfig}
                  disabled={isLoading}
                  className="btn-primary flex items-center gap-2 disabled:opacity-50 mt-6"
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <Save className="w-5 h-5" />
                  )}
                  Sauvegarder les modifications
                </button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
