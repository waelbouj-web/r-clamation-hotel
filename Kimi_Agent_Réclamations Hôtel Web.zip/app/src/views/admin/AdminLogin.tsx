import { useState } from 'react';
import type { View } from '@/types';
import { dataStore } from '@/store/dataStore';
import { 
  ArrowLeft, 
  User, 
  Lock, 
  Eye, 
  EyeOff,
  Loader2,
  Shield
} from 'lucide-react';
import { toast } from 'sonner';

interface AdminLoginProps {
  onNavigate: (view: View) => void;
}

export default function AdminLogin({ onNavigate }: AdminLoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showDemo, setShowDemo] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username || !password) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const admin = dataStore.loginAdmin(username, password);
    
    if (admin) {
      toast.success('Connexion réussie !', {
        description: `Bienvenue, ${admin.name}`,
      });
      onNavigate('admin-dashboard');
    } else {
      toast.error('Identifiants incorrects');
    }
    
    setIsLoading(false);
  };

  const fillDemoData = (type: 'admin' | 'manager') => {
    if (type === 'admin') {
      setUsername('admin');
      setPassword('admin123');
    } else {
      setUsername('manager');
      setPassword('manager123');
    }
    setShowDemo(false);
  };

  return (
    <div className="min-h-screen gradient-hero flex items-center justify-center p-4">
      {/* Background shapes */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-white/10 rounded-full blur-3xl animate-shape-float-1"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-white/10 rounded-full blur-3xl animate-shape-float-2"></div>
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Back button */}
        <button
          onClick={() => onNavigate('landing')}
          className="absolute -top-16 left-0 flex items-center gap-2 text-white/80 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Retour
        </button>

        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-2xl bg-white flex items-center justify-center mx-auto mb-4 shadow-xl animate-bounce-in">
            <Shield className="w-10 h-10 text-[#0075D5]" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Espace Administrateur</h1>
          <p className="text-white/80">Connectez-vous pour gérer les réclamations</p>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-2xl shadow-2xl p-8 animate-slide-up">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nom d'utilisateur
              </label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="admin"
                  className="input-field pl-12"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mot de passe
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="input-field pl-12 pr-12"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full btn-primary flex items-center justify-center gap-2 disabled:opacity-70"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Connexion...
                </>
              ) : (
                'Se connecter'
              )}
            </button>
          </form>

          {/* Demo hint */}
          <div className="mt-6 pt-6 border-t border-gray-100">
            <button
              onClick={() => setShowDemo(!showDemo)}
              className="text-sm text-[#0075D5] hover:underline w-full text-center"
            >
              Données de démonstration
            </button>
            
            {showDemo && (
              <div className="mt-4 p-4 bg-blue-50 rounded-lg animate-fade-in space-y-3">
                <p className="text-sm text-gray-600">
                  Utilisez ces identifiants pour tester :
                </p>
                
                <div className="space-y-3">
                  <div className="p-3 bg-white rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Super Admin</span>
                      <button
                        onClick={() => fillDemoData('admin')}
                        className="text-xs bg-[#0075D5] text-white px-2 py-1 rounded hover:bg-[#0059A7] transition-colors"
                      >
                        Utiliser
                      </button>
                    </div>
                    <div className="text-xs text-gray-500 space-y-1">
                      <div>Username: admin</div>
                      <div>Password: admin123</div>
                    </div>
                  </div>
                  
                  <div className="p-3 bg-white rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Manager</span>
                      <button
                        onClick={() => fillDemoData('manager')}
                        className="text-xs bg-[#0075D5] text-white px-2 py-1 rounded hover:bg-[#0059A7] transition-colors"
                      >
                        Utiliser
                      </button>
                    </div>
                    <div className="text-xs text-gray-500 space-y-1">
                      <div>Username: manager</div>
                      <div>Password: manager123</div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Client link */}
        <p className="text-center mt-6 text-white/80 text-sm">
          Vous êtes client ?{' '}
          <button
            onClick={() => onNavigate('client-login')}
            className="text-white font-semibold hover:underline"
          >
            Connexion Client
          </button>
        </p>
      </div>
    </div>
  );
}
