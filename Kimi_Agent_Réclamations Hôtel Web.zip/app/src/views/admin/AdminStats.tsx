import { useEffect, useState } from 'react';
import type { View, Admin, Stats } from '@/types';
import { dataStore } from '@/store/dataStore';
import AdminSidebar from '@/components/AdminSidebar';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown,
  Clock,
  CheckCircle,
  Star,
  Calendar,
  PieChart,
  Activity,
  Users,
  MessageSquare,
  Download,
  Timer
} from 'lucide-react';
import { toast } from 'sonner';

interface AdminStatsProps {
  onNavigate: (view: View) => void;
}

export default function AdminStats({ onNavigate }: AdminStatsProps) {
  const [admin, setAdmin] = useState<Admin | null>(null);
  const [stats, setStats] = useState<Stats | null>(null);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | 'all'>('30d');

  useEffect(() => {
    const currentAdmin = dataStore.getCurrentAdmin();
    if (!currentAdmin) {
      toast.error('Veuillez vous connecter');
      onNavigate('admin-login');
      return;
    }
    setAdmin(currentAdmin);
    
    const allStats = dataStore.getStats();
    setStats(allStats);
  }, [onNavigate]);

  const getDepartmentChartData = () => {
    if (!stats) return [];
    return Object.entries(stats.complaintsByDepartment)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8);
  };

  const getPriorityChartData = () => {
    if (!stats) return [];
    return Object.entries(stats.complaintsByPriority)
      .sort((a, b) => b[1] - a[1]);
  };

  const getMaxValue = (data: [string, number][]) => {
    return Math.max(...data.map(d => d[1]), 1);
  };

  const handleExport = () => {
    toast.success('Rapport exporté', {
      description: 'Le fichier CSV a été téléchargé.',
    });
  };

  const handleLogout = () => {
    dataStore.logoutAdmin();
    toast.success('Déconnexion réussie');
    onNavigate('landing');
  };

  if (!admin || !stats) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <AdminSidebar 
        admin={admin}
        currentView="admin-stats"
        onNavigate={onNavigate}
        onLogout={handleLogout}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* Header */}
        <header className="bg-white shadow-sm sticky top-0 lg:top-0 z-30 mt-16 lg:mt-0">
          <div className="px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Statistiques détaillées</h2>
                <p className="text-gray-600">Analyse des performances</p>
              </div>
              <button
                onClick={handleExport}
                className="flex items-center gap-2 px-4 py-2 bg-[#0075D5] text-white rounded-lg hover:bg-[#0059A7] transition-colors"
              >
                <Download className="w-4 h-4" />
                Exporter le rapport
              </button>
            </div>
          </div>
        </header>

        <div className="p-4 sm:p-6 lg:p-8 space-y-6">
          {/* Time Range Selector */}
          <div className="flex justify-center">
            <div className="inline-flex bg-white rounded-xl shadow-sm p-1">
              {[
                { value: '7d', label: '7 jours' },
                { value: '30d', label: '30 jours' },
                { value: '90d', label: '90 jours' },
                { value: 'all', label: 'Tout' },
              ].map((range) => (
                <button
                  key={range.value}
                  onClick={() => setTimeRange(range.value as any)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    timeRange === range.value
                      ? 'bg-[#0075D5] text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {range.label}
                </button>
              ))}
            </div>
          </div>

          {/* Overview Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { 
                label: 'Total réclamations', 
                value: stats.totalComplaints, 
                icon: MessageSquare, 
                color: 'bg-blue-500',
                trend: null
              },
              { 
                label: 'Taux de résolution', 
                value: `${Math.round((stats.resolvedComplaints / Math.max(stats.totalComplaints, 1)) * 100)}%`, 
                icon: CheckCircle, 
                color: 'bg-green-500',
                trend: 'up'
              },
              { 
                label: 'Satisfaction', 
                value: `${stats.satisfactionRate.toFixed(0)}%`, 
                icon: Star, 
                color: 'bg-yellow-500',
                trend: stats.satisfactionRate >= 80 ? 'up' : 'down'
              },
              { 
                label: 'Temps moyen', 
                value: `${stats.averageResolutionTime.toFixed(1)}h`, 
                icon: Timer, 
                color: 'bg-purple-500',
                trend: stats.averageResolutionTime <= 24 ? 'up' : 'down'
              },
            ].map((stat, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-6 shadow-sm"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className={`w-10 h-10 rounded-lg ${stat.color} flex items-center justify-center mb-3`}>
                  <stat.icon className="w-5 h-5 text-white" />
                </div>
                <div className="flex items-end gap-2">
                  <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                  {stat.trend && (
                    stat.trend === 'up' ? (
                      <TrendingUp className="w-4 h-4 text-green-500 mb-1" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-500 mb-1" />
                    )
                  )}
                </div>
                <div className="text-sm text-gray-500">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Charts Grid */}
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Status Distribution */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="font-semibold text-gray-900 mb-6 flex items-center gap-2">
                <PieChart className="w-5 h-5 text-[#0075D5]" />
                Répartition par statut
              </h3>
              
              <div className="space-y-4">
                {[
                  { label: 'En attente', value: stats.pendingComplaints, color: 'bg-yellow-500' },
                  { label: 'En cours', value: stats.inProgressComplaints, color: 'bg-blue-500' },
                  { label: 'Résolues', value: stats.resolvedComplaints, color: 'bg-green-500' },
                  { label: 'Fermées', value: stats.closedComplaints, color: 'bg-gray-500' },
                ].map((item) => (
                  <div key={item.label}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">{item.label}</span>
                      <span className="font-medium text-gray-900">
                        {item.value} ({stats.totalComplaints > 0 ? Math.round((item.value / stats.totalComplaints) * 100) : 0}%)
                      </span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${item.color} transition-all duration-500`}
                        style={{ width: `${stats.totalComplaints > 0 ? (item.value / stats.totalComplaints) * 100 : 0}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Priority Distribution */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="font-semibold text-gray-900 mb-6 flex items-center gap-2">
                <Activity className="w-5 h-5 text-[#0075D5]" />
                Répartition par priorité
              </h3>
              
              <div className="space-y-4">
                {getPriorityChartData().map(([priority, count]) => {
                  const colors: Record<string, string> = {
                    urgent: 'bg-red-500',
                    high: 'bg-orange-500',
                    medium: 'bg-blue-500',
                    low: 'bg-gray-400',
                  };
                  const labels: Record<string, string> = {
                    urgent: 'Urgente',
                    high: 'Haute',
                    medium: 'Moyenne',
                    low: 'Basse',
                  };
                  return (
                    <div key={priority}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-gray-600">{labels[priority] || priority}</span>
                        <span className="font-medium text-gray-900">
                          {count} ({stats.totalComplaints > 0 ? Math.round((count / stats.totalComplaints) * 100) : 0}%)
                        </span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${colors[priority] || 'bg-gray-400'} transition-all duration-500`}
                          style={{ width: `${stats.totalComplaints > 0 ? (count / stats.totalComplaints) * 100 : 0}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Department Stats */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="font-semibold text-gray-900 mb-6 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-[#0075D5]" />
              Réclamations par département
            </h3>
            
            <div className="space-y-4">
              {getDepartmentChartData().map(([dept, count]) => (
                <div key={dept} className="flex items-center gap-4">
                  <span className="text-sm text-gray-600 w-32 truncate">{dept}</span>
                  <div className="flex-1 h-8 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full gradient-hero transition-all duration-500 flex items-center justify-end pr-3"
                      style={{ 
                        width: `${Math.max(5, (count / getMaxValue(getDepartmentChartData())) * 100)}%` 
                      }}
                    >
                      <span className="text-sm text-white font-medium">{count}</span>
                    </div>
                  </div>
                  <span className="text-sm text-gray-500 w-12 text-right">
                    {stats.totalComplaints > 0 ? Math.round((count / stats.totalComplaints) * 100) : 0}%
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Daily Activity */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="font-semibold text-gray-900 mb-6 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#0075D5]" />
              Activité des 30 derniers jours
            </h3>
            
            <div className="overflow-x-auto">
              <div className="min-w-[600px]">
                <div className="flex items-end gap-2 h-48 mb-4">
                  {stats.dailyStats.map((day) => {
                    const maxValue = Math.max(...stats.dailyStats.map(d => d.created), 1);
                    const height = Math.max(10, (day.created / maxValue) * 100);
                    
                    return (
                      <div
                        key={day.date}
                        className="flex-1 flex flex-col items-center gap-1 group"
                      >
                        <div className="relative w-full">
                          <div
                            className="w-full bg-[#0075D5] rounded-t transition-all duration-300 group-hover:bg-[#0059A7]"
                            style={{ height: `${height}%` }}
                          />
                          <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                            {day.created} créées
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>{new Date(stats.dailyStats[0].date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</span>
                  <span>{new Date(stats.dailyStats[Math.floor(stats.dailyStats.length / 2)].date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</span>
                  <span>{new Date(stats.dailyStats[stats.dailyStats.length - 1].date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white">
              <div className="flex items-center gap-3 mb-4">
                <Users className="w-8 h-8" />
                <h4 className="font-semibold">Performance</h4>
              </div>
              <div className="text-4xl font-bold mb-2">
                {Math.round((stats.resolvedComplaints / Math.max(stats.totalComplaints, 1)) * 100)}%
              </div>
              <p className="text-blue-100 text-sm">
                {stats.resolvedComplaints} sur {stats.totalComplaints} réclamations
              </p>
            </div>

            <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white">
              <div className="flex items-center gap-3 mb-4">
                <Star className="w-8 h-8" />
                <h4 className="font-semibold">Satisfaction client</h4>
              </div>
              <div className="text-4xl font-bold mb-2">
                {stats.satisfactionRate.toFixed(0)}%
              </div>
              <p className="text-green-100 text-sm">
                Note moyenne: {(stats.satisfactionRate / 20).toFixed(1)}/5
              </p>
            </div>

            <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white">
              <div className="flex items-center gap-3 mb-4">
                <Clock className="w-8 h-8" />
                <h4 className="font-semibold">Efficacité</h4>
              </div>
              <div className="text-4xl font-bold mb-2">
                {stats.averageResolutionTime.toFixed(1)}h
              </div>
              <p className="text-purple-100 text-sm">
                Objectif: 24h
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
