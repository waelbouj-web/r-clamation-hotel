import { useState, useEffect } from 'react';
import type { View, Client, Complaint } from '@/types';
import { dataStore } from '@/store/dataStore';
import { 
  ArrowLeft, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  XCircle,
  MessageCircle,
  Calendar,
  Building2,
  Tag,
  Send,
  Loader2,
  Star,
  ChevronDown
} from 'lucide-react';
import { toast } from 'sonner';

interface TrackComplaintsProps {
  onNavigate: (view: View) => void;
}

export default function TrackComplaints({ onNavigate }: TrackComplaintsProps) {
  const [client, setClient] = useState<Client | null>(null);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [newNote, setNewNote] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedbackRating, setFeedbackRating] = useState(0);
  const [feedbackComment, setFeedbackComment] = useState('');

  useEffect(() => {
    const currentClient = dataStore.getCurrentClient();
    if (!currentClient) {
      toast.error('Veuillez vous connecter');
      onNavigate('client-login');
      return;
    }
    setClient(currentClient);
    loadComplaints(currentClient.id);
  }, [onNavigate]);

  const loadComplaints = (clientId: string) => {
    const clientComplaints = dataStore.getComplaintsByClient(clientId);
    setComplaints(clientComplaints);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-5 h-5" />;
      case 'in-progress':
        return <AlertCircle className="w-5 h-5" />;
      case 'resolved':
        return <CheckCircle className="w-5 h-5" />;
      case 'closed':
        return <XCircle className="w-5 h-5" />;
      default:
        return <Clock className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'in-progress':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'resolved':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'closed':
        return 'bg-gray-100 text-gray-700 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'pending':
        return 'En attente';
      case 'in-progress':
        return 'En cours';
      case 'resolved':
        return 'Résolue';
      case 'closed':
        return 'Fermée';
      default:
        return status;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return <span className="badge badge-urgent">Urgente</span>;
      case 'high':
        return <span className="badge badge-high">Haute</span>;
      case 'medium':
        return <span className="badge badge-medium">Moyenne</span>;
      case 'low':
        return <span className="badge badge-low">Basse</span>;
      default:
        return null;
    }
  };

  const handleAddNote = async () => {
    if (!selectedComplaint || !newNote.trim()) return;

    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));

    dataStore.addNoteToComplaint(selectedComplaint.id, {
      author: client?.name || 'Client',
      authorRole: 'client',
      content: newNote,
    });

    toast.success('Commentaire ajouté');
    setNewNote('');
    loadComplaints(client!.id);
    setSelectedComplaint(dataStore.getComplaintById(selectedComplaint.id) || null);
    setIsLoading(false);
  };

  const handleSubmitFeedback = async () => {
    if (!selectedComplaint || feedbackRating === 0) {
      toast.error('Veuillez donner une note');
      return;
    }

    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));

    dataStore.addFeedbackToComplaint(selectedComplaint.id, {
      rating: feedbackRating,
      comment: feedbackComment,
    });

    toast.success('Merci pour votre avis !');
    setShowFeedback(false);
    setFeedbackRating(0);
    setFeedbackComment('');
    loadComplaints(client!.id);
    setSelectedComplaint(dataStore.getComplaintById(selectedComplaint.id) || null);
    setIsLoading(false);
  };

  if (!client) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={() => selectedComplaint ? setSelectedComplaint(null) : onNavigate('client-dashboard')}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              {selectedComplaint ? 'Retour à la liste' : 'Tableau de bord'}
            </button>
            <h1 className="text-lg font-bold text-gray-900">
              {selectedComplaint ? 'Détails de la réclamation' : 'Mes réclamations'}
            </h1>
            <div className="w-24"></div>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {selectedComplaint ? (
          // Detail View
          <div className="space-y-6 animate-fade-in">
            {/* Header Card */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(selectedComplaint.status)}`}>
                      {getStatusIcon(selectedComplaint.status)}
                      {getStatusLabel(selectedComplaint.status)}
                    </span>
                    {getPriorityBadge(selectedComplaint.priority)}
                  </div>
                  <h2 className="text-xl font-bold text-gray-900">{selectedComplaint.title}</h2>
                </div>
                {selectedComplaint.status === 'resolved' && !selectedComplaint.feedback && (
                  <button
                    onClick={() => setShowFeedback(true)}
                    className="btn-primary flex items-center gap-2"
                  >
                    <Star className="w-4 h-4" />
                    Donner mon avis
                  </button>
                )}
              </div>

              <div className="grid sm:grid-cols-3 gap-4 text-sm">
                <div className="flex items-center gap-2 text-gray-600">
                  <Building2 className="w-4 h-4" />
                  {selectedComplaint.department} • {selectedComplaint.subDepartment}
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Calendar className="w-4 h-4" />
                  {new Date(selectedComplaint.createdAt).toLocaleDateString('fr-FR')}
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Tag className="w-4 h-4" />
                  #{selectedComplaint.id.split('-')[1]}
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="font-semibold text-gray-900 mb-3">Description</h3>
              <p className="text-gray-700 whitespace-pre-wrap">{selectedComplaint.description}</p>
            </div>

            {/* Feedback if exists */}
            {selectedComplaint.feedback && (
              <div className="bg-green-50 rounded-xl p-6 border border-green-100">
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <Star className="w-5 h-5 text-green-600" />
                  Votre avis
                </h3>
                <div className="flex items-center gap-2 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < selectedComplaint.feedback!.rating
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                {selectedComplaint.feedback.comment && (
                  <p className="text-gray-700">{selectedComplaint.feedback.comment}</p>
                )}
              </div>
            )}

            {/* Notes */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <MessageCircle className="w-5 h-5" />
                Commentaires ({selectedComplaint.notes.length})
              </h3>

              <div className="space-y-4 mb-6">
                {selectedComplaint.notes.length === 0 ? (
                  <p className="text-gray-500 text-center py-4">
                    Aucun commentaire pour le moment.
                  </p>
                ) : (
                  selectedComplaint.notes.map((note) => (
                    <div
                      key={note.id}
                      className={`p-4 rounded-lg ${
                        note.authorRole === 'client'
                          ? 'bg-blue-50 ml-8'
                          : 'bg-gray-50 mr-8'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-gray-900">{note.author}</span>
                        <span className="text-xs text-gray-500">
                          {new Date(note.createdAt).toLocaleString('fr-FR')}
                        </span>
                      </div>
                      <p className="text-gray-700">{note.content}</p>
                    </div>
                  ))
                )}
              </div>

              {/* Add Note */}
              <div className="flex gap-3">
                <input
                  type="text"
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Ajouter un commentaire..."
                  className="flex-1 input-field"
                  onKeyPress={(e) => e.key === 'Enter' && handleAddNote()}
                />
                <button
                  onClick={handleAddNote}
                  disabled={isLoading || !newNote.trim()}
                  className="btn-primary px-4 disabled:opacity-50"
                >
                  {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                </button>
              </div>
            </div>
          </div>
        ) : (
          // List View
          <div className="space-y-4">
            {complaints.length === 0 ? (
              <div className="bg-white rounded-xl shadow-sm p-12 text-center">
                <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="w-10 h-10 text-gray-400" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Aucune réclamation
                </h3>
                <p className="text-gray-600 mb-6">
                  Vous n'avez pas encore soumis de réclamation.
                </p>
                <button
                  onClick={() => onNavigate('client-new-complaint')}
                  className="btn-primary"
                >
                  Soumettre une réclamation
                </button>
              </div>
            ) : (
              complaints.map((complaint, index) => (
                <div
                  key={complaint.id}
                  className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-all cursor-pointer animate-slide-up"
                  style={{ animationDelay: `${index * 100}ms` }}
                  onClick={() => setSelectedComplaint(complaint)}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusColor(complaint.status)}`}>
                          {getStatusIcon(complaint.status)}
                          {getStatusLabel(complaint.status)}
                        </span>
                        {getPriorityBadge(complaint.priority)}
                        {complaint.feedback && (
                          <span className="inline-flex items-center gap-1 text-xs text-green-600">
                            <Star className="w-3 h-3 fill-current" />
                            Avis donné
                          </span>
                        )}
                      </div>
                      <h3 className="font-semibold text-gray-900 mb-1">{complaint.title}</h3>
                      <p className="text-sm text-gray-500 line-clamp-2">{complaint.description}</p>
                      <div className="flex items-center gap-4 mt-3 text-xs text-gray-400">
                        <span>{complaint.department}</span>
                        <span>•</span>
                        <span>{new Date(complaint.createdAt).toLocaleDateString('fr-FR')}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <MessageCircle className="w-3 h-3" />
                          {complaint.notes.length} commentaire{complaint.notes.length !== 1 ? 's' : ''}
                        </span>
                      </div>
                    </div>
                    <ChevronDown className="w-5 h-5 text-gray-400" />
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </main>

      {/* Feedback Modal */}
      {showFeedback && selectedComplaint && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl p-6 max-w-md w-full animate-scale-in">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Donnez votre avis
            </h3>
            <p className="text-gray-600 mb-6">
              Votre réclamation a été résolue. Comment évaluez-vous notre service ?
            </p>

            <div className="flex justify-center gap-2 mb-6">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setFeedbackRating(star)}
                  className="p-1 hover:scale-110 transition-transform"
                >
                  <Star
                    className={`w-8 h-8 ${
                      star <= feedbackRating
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
            </div>

            <textarea
              value={feedbackComment}
              onChange={(e) => setFeedbackComment(e.target.value)}
              placeholder="Commentaire (optionnel)..."
              rows={3}
              className="input-field resize-none mb-6"
            />

            <div className="flex gap-3">
              <button
                onClick={() => setShowFeedback(false)}
                className="flex-1 py-3 border-2 border-gray-200 rounded-lg font-semibold text-gray-600 hover:border-gray-300 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleSubmitFeedback}
                disabled={isLoading || feedbackRating === 0}
                className="flex-1 btn-primary disabled:opacity-50"
              >
                {isLoading ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : 'Envoyer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
