import { useEffect, useState } from 'react';
import type { View, Client, Complaint } from '@/types';
import { dataStore } from '@/store/dataStore';
import { 
  MessageSquare, 
  Plus, 
  List, 
  BarChart3, 
  LogOut, 
  User, 
  Hotel,
  Clock,
  CheckCircle,
  AlertCircle,
  ChevronRight,
  Star
} from 'lucide-react';
import { toast } from 'sonner';

interface ClientDashboardProps {
  onNavigate: (view: View) => void;
}

export default function ClientDashboard({ onNavigate }: ClientDashboardProps) {
  const [client, setClient] = useState<Client | null>(null);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    inProgress: 0,
    resolved: 0,
  });

  useEffect(() => {
    const currentClient = dataStore.getCurrentClient();
    if (!currentClient) {
      toast.error('Veuillez vous connecter');
      onNavigate('client-login');
      return;
    }
    setClient(currentClient);
    
    const clientComplaints = dataStore.getComplaintsByClient(currentClient.id);
    setComplaints(clientComplaints);
    
    setStats({
      total: clientComplaints.length,
      pending: clientComplaints.filter(c => c.status === 'pending').length,
      inProgress: clientComplaints.filter(c => c.status === 'in-progress').length,
      resolved: clientComplaints.filter(c => c.status === 'resolved' || c.status === 'closed').length,
    });
  }, [onNavigate]);

  const handleLogout = () => {
    dataStore.logoutClient();
    toast.success('Déconnexion réussie');
    onNavigate('landing');
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      case 'in-progress':
        return <AlertCircle className="w-5 h-5 text-blue-500" />;
      case 'resolved':
      case 'closed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      default:
        return <Clock className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <span className="badge badge-pending">En attente</span>;
      case 'in-progress':
        return <span className="badge badge-in-progress">En cours</span>;
      case 'resolved':
        return <span className="badge badge-resolved">Résolue</span>;
      case 'closed':
        return <span className="badge badge-closed">Fermée</span>;
      default:
        return <span className="badge">Inconnu</span>;
    }
  };

  if (!client) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg gradient-hero flex items-center justify-center">
                <MessageSquare className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-900">Hôtel Réclamation</h1>
                <p className="text-xs text-gray-500">Espace Client</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="hidden sm:flex items-center gap-3 px-4 py-2 bg-gray-50 rounded-lg">
                <div className="w-8 h-8 rounded-full gradient-hero flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <div className="text-sm">
                  <p className="font-medium text-gray-900">{client.name}</p>
                  <p className="text-gray-500 flex items-center gap-1">
                    <Hotel className="w-3 h-3" />
                    Ch. {client.roomNumber}
                  </p>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="p-2 text-gray-500 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                title="Déconnexion"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome */}
        <div className="mb-8 animate-slide-down">
          <h2 className="text-2xl font-bold text-gray-900">
            Bonjour, {client.name} !
          </h2>
          <p className="text-gray-600">
            Bienvenue dans votre espace de gestion des réclamations.
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <button
            onClick={() => onNavigate('client-new-complaint')}
            className="group bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 text-left"
          >
            <div className="w-12 h-12 rounded-xl gradient-hero flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Plus className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-1">Nouvelle réclamation</h3>
            <p className="text-sm text-gray-500">Soumettre un nouveau problème</p>
          </button>

          <button
            onClick={() => onNavigate('client-track')}
            className="group bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 text-left"
          >
            <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <List className="w-6 h-6 text-[#0075D5]" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-1">Mes réclamations</h3>
            <p className="text-sm text-gray-500">Suivre l'état de mes demandes</p>
          </button>

          <button
            onClick={() => onNavigate('client-stats')}
            className="group bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 text-left"
          >
            <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <BarChart3 className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-1">Statistiques</h3>
            <p className="text-sm text-gray-500">Voir mes statistiques</p>
          </button>

          <button
            onClick={() => onNavigate('client-feedback')}
            className="group bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 text-left"
          >
            <div className="w-12 h-12 rounded-xl bg-yellow-100 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Star className="w-6 h-6 text-yellow-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-1">Mes avis</h3>
            <p className="text-sm text-gray-500">Donner mon feedback</p>
          </button>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total', value: stats.total, icon: List, color: 'bg-gray-100 text-gray-600' },
            { label: 'En attente', value: stats.pending, icon: Clock, color: 'bg-yellow-100 text-yellow-600' },
            { label: 'En cours', value: stats.inProgress, icon: AlertCircle, color: 'bg-blue-100 text-blue-600' },
            { label: 'Résolues', value: stats.resolved, icon: CheckCircle, color: 'bg-green-100 text-green-600' },
          ].map((stat, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-6 shadow-sm"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className={`w-10 h-10 rounded-lg ${stat.color} flex items-center justify-center mb-3`}>
                <stat.icon className="w-5 h-5" />
              </div>
              <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
              <div className="text-sm text-gray-500">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Recent Complaints */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">Réclamations récentes</h3>
            <button
              onClick={() => onNavigate('client-track')}
              className="text-sm text-[#0075D5] hover:underline flex items-center gap-1"
            >
              Voir tout
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          
          {complaints.length === 0 ? (
            <div className="p-8 text-center">
              <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
                <MessageSquare className="w-8 h-8 text-gray-400" />
              </div>
              <h4 className="text-lg font-medium text-gray-900 mb-2">
                Aucune réclamation
              </h4>
              <p className="text-gray-500 mb-4">
                Vous n'avez pas encore soumis de réclamation.
              </p>
              <button
                onClick={() => onNavigate('client-new-complaint')}
                className="btn-primary"
              >
                Soumettre une réclamation
              </button>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {complaints.slice(0, 5).map((complaint) => (
                <div
                  key={complaint.id}
                  className="px-6 py-4 hover:bg-gray-50 transition-colors flex items-center justify-between"
                >
                  <div className="flex items-center gap-4">
                    {getStatusIcon(complaint.status)}
                    <div>
                      <h4 className="font-medium text-gray-900">{complaint.title}</h4>
                      <p className="text-sm text-gray-500">
                        {complaint.department} • {new Date(complaint.createdAt).toLocaleDateString('fr-FR')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {getStatusBadge(complaint.status)}
                    <button
                      onClick={() => onNavigate('client-track')}
                      className="p-2 hover:bg-gray-200 rounded-lg transition-colors"
                    >
                      <ChevronRight className="w-5 h-5 text-gray-400" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
