import { useState, useEffect } from 'react';
import type { View, Client, Complaint } from '@/types';
import { dataStore } from '@/store/dataStore';
import { 
  ArrowLeft, 
  BarChart3, 
  TrendingUp, 
  TrendingDown,
  Clock,
  CheckCircle,
  Star,
  Calendar,
  PieChart
} from 'lucide-react';
import { toast } from 'sonner';

interface ClientStatsProps {
  onNavigate: (view: View) => void;
}

export default function ClientStats({ onNavigate }: ClientStatsProps) {
  const [client, setClient] = useState<Client | null>(null);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    inProgress: 0,
    resolved: 0,
    closed: 0,
    avgRating: 0,
    resolutionRate: 0,
  });

  useEffect(() => {
    const currentClient = dataStore.getCurrentClient();
    if (!currentClient) {
      toast.error('Veuillez vous connecter');
      onNavigate('client-login');
      return;
    }
    setClient(currentClient);
    
    const clientComplaints = dataStore.getComplaintsByClient(currentClient.id);
    setComplaints(clientComplaints);
    
    const total = clientComplaints.length;
    const resolved = clientComplaints.filter(c => c.status === 'resolved' || c.status === 'closed').length;
    const withFeedback = clientComplaints.filter(c => c.feedback);
    const avgRating = withFeedback.length > 0
      ? withFeedback.reduce((acc, c) => acc + (c.feedback?.rating || 0), 0) / withFeedback.length
      : 0;

    setStats({
      total,
      pending: clientComplaints.filter(c => c.status === 'pending').length,
      inProgress: clientComplaints.filter(c => c.status === 'in-progress').length,
      resolved: clientComplaints.filter(c => c.status === 'resolved').length,
      closed: clientComplaints.filter(c => c.status === 'closed').length,
      avgRating,
      resolutionRate: total > 0 ? Math.round((resolved / total) * 100) : 0,
    });
  }, [onNavigate]);

  const getDepartmentStats = () => {
    const deptCount: Record<string, number> = {};
    complaints.forEach(c => {
      deptCount[c.department] = (deptCount[c.department] || 0) + 1;
    });
    return Object.entries(deptCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  };

  const getMonthlyStats = () => {
    const monthly: Record<string, number> = {};
    complaints.forEach(c => {
      const month = new Date(c.createdAt).toLocaleString('fr-FR', { month: 'short', year: '2-digit' });
      monthly[month] = (monthly[month] || 0) + 1;
    });
    return Object.entries(monthly).slice(-6);
  };

  if (!client) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={() => onNavigate('client-dashboard')}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              Tableau de bord
            </button>
            <h1 className="text-lg font-bold text-gray-900">Mes statistiques</h1>
            <div className="w-24"></div>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Overview Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { 
              label: 'Total réclamations', 
              value: stats.total, 
              icon: BarChart3, 
              color: 'bg-blue-100 text-blue-600',
              trend: null
            },
            { 
              label: 'Taux de résolution', 
              value: `${stats.resolutionRate}%`, 
              icon: CheckCircle, 
              color: 'bg-green-100 text-green-600',
              trend: stats.resolutionRate >= 80 ? 'up' : 'down'
            },
            { 
              label: 'Note moyenne', 
              value: stats.avgRating > 0 ? stats.avgRating.toFixed(1) : '-', 
              icon: Star, 
              color: 'bg-yellow-100 text-yellow-600',
              trend: null
            },
            { 
              label: 'En cours', 
              value: stats.inProgress + stats.pending, 
              icon: Clock, 
              color: 'bg-orange-100 text-orange-600',
              trend: null
            },
          ].map((stat, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-6 shadow-sm animate-slide-up"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className={`w-10 h-10 rounded-lg ${stat.color} flex items-center justify-center mb-3`}>
                <stat.icon className="w-5 h-5" />
              </div>
              <div className="flex items-end gap-2">
                <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                {stat.trend && (
                  stat.trend === 'up' ? (
                    <TrendingUp className="w-4 h-4 text-green-500 mb-1" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-red-500 mb-1" />
                  )
                )}
              </div>
              <div className="text-sm text-gray-500">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Status Distribution */}
        <div className="grid lg:grid-cols-2 gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="font-semibold text-gray-900 mb-6 flex items-center gap-2">
              <PieChart className="w-5 h-5 text-[#0075D5]" />
              Répartition par statut
            </h3>
            
            {stats.total === 0 ? (
              <div className="text-center py-8 text-gray-500">
                Aucune donnée disponible
              </div>
            ) : (
              <div className="space-y-4">
                {[
                  { label: 'En attente', value: stats.pending, color: 'bg-yellow-500' },
                  { label: 'En cours', value: stats.inProgress, color: 'bg-blue-500' },
                  { label: 'Résolues', value: stats.resolved, color: 'bg-green-500' },
                  { label: 'Fermées', value: stats.closed, color: 'bg-gray-500' },
                ].map((item) => (
                  <div key={item.label}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">{item.label}</span>
                      <span className="font-medium text-gray-900">
                        {item.value} ({stats.total > 0 ? Math.round((item.value / stats.total) * 100) : 0}%)
                      </span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${item.color} transition-all duration-500`}
                        style={{ width: `${stats.total > 0 ? (item.value / stats.total) * 100 : 0}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="font-semibold text-gray-900 mb-6 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#0075D5]" />
              Réclamations par mois
            </h3>
            
            {getMonthlyStats().length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                Aucune donnée disponible
              </div>
            ) : (
              <div className="space-y-3">
                {getMonthlyStats().map(([month, count]) => (
                  <div key={month} className="flex items-center gap-4">
                    <span className="text-sm text-gray-600 w-16">{month}</span>
                    <div className="flex-1 h-6 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full gradient-hero transition-all duration-500 flex items-center justify-end pr-2"
                        style={{ 
                          width: `${Math.max(10, (count / Math.max(...getMonthlyStats().map(s => s[1]))) * 100)}%` 
                        }}
                      >
                        <span className="text-xs text-white font-medium">{count}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Department Stats */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="font-semibold text-gray-900 mb-6">
            Réclamations par département
          </h3>
          
          {getDepartmentStats().length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              Aucune donnée disponible
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {getDepartmentStats().map(([dept, count]) => (
                <div
                  key={dept}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                >
                  <span className="text-gray-700">{dept}</span>
                  <span className="px-3 py-1 bg-white rounded-full text-sm font-medium text-gray-900">
                    {count}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Satisfaction Info */}
        {stats.avgRating > 0 && (
          <div className="mt-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6 border border-green-100">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-sm">
                <Star className="w-8 h-8 text-yellow-500 fill-yellow-500" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">
                  Merci pour votre fidélité !
                </h3>
                <p className="text-gray-600">
                  Votre note moyenne de <span className="font-semibold text-[#0075D5]">{stats.avgRating.toFixed(1)}/5</span> nous aide à améliorer nos services.
                </p>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
