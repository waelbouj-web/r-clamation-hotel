import { useState, useEffect } from 'react';
import type { View, Client, Complaint } from '@/types';
import { dataStore } from '@/store/dataStore';
import { 
  ArrowLeft, 
  Star, 
  MessageSquare,
  CheckCircle,
  ThumbsUp,
  ThumbsDown,
  Send,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner';

interface ClientFeedbackProps {
  onNavigate: (view: View) => void;
}

export default function ClientFeedback({ onNavigate }: ClientFeedbackProps) {
  const [client, setClient] = useState<Client | null>(null);
  const [resolvedComplaints, setResolvedComplaints] = useState<Complaint[]>([]);
  const [complaintsWithFeedback, setComplaintsWithFeedback] = useState<Complaint[]>([]);
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const currentClient = dataStore.getCurrentClient();
    if (!currentClient) {
      toast.error('Veuillez vous connecter');
      onNavigate('client-login');
      return;
    }
    setClient(currentClient);
    loadComplaints(currentClient.id);
  }, [onNavigate]);

  const loadComplaints = (clientId: string) => {
    const clientComplaints = dataStore.getComplaintsByClient(clientId);
    const resolved = clientComplaints.filter(c => c.status === 'resolved' && !c.feedback);
    const withFeedback = clientComplaints.filter(c => c.feedback);
    setResolvedComplaints(resolved);
    setComplaintsWithFeedback(withFeedback);
  };

  const handleSubmitFeedback = async () => {
    if (!selectedComplaint || rating === 0) {
      toast.error('Veuillez donner une note');
      return;
    }

    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));

    dataStore.addFeedbackToComplaint(selectedComplaint.id, {
      rating,
      comment,
    });

    toast.success('Merci pour votre avis !', {
      description: 'Votre feedback nous aide à nous améliorer.',
    });

    setSelectedComplaint(null);
    setRating(0);
    setComment('');
    loadComplaints(client!.id);
    setIsLoading(false);
  };

  const getRatingLabel = (rating: number) => {
    switch (rating) {
      case 1: return 'Très insatisfait';
      case 2: return 'Insatisfait';
      case 3: return 'Neutre';
      case 4: return 'Satisfait';
      case 5: return 'Très satisfait';
      default: return '';
    }
  };

  if (!client) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={() => selectedComplaint ? setSelectedComplaint(null) : onNavigate('client-dashboard')}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              {selectedComplaint ? 'Retour' : 'Tableau de bord'}
            </button>
            <h1 className="text-lg font-bold text-gray-900">
              {selectedComplaint ? 'Donner mon avis' : 'Mes avis'}
            </h1>
            <div className="w-20"></div>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {selectedComplaint ? (
          // Feedback Form
          <div className="bg-white rounded-2xl shadow-sm p-8 animate-fade-in">
            <div className="text-center mb-8">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                Votre réclamation a été résolue
              </h2>
              <p className="text-gray-600">
                Comment évaluez-vous la résolution de "{selectedComplaint.title}" ?
              </p>
            </div>

            {/* Star Rating */}
            <div className="text-center mb-8">
              <div className="flex justify-center gap-2 mb-3">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setRating(star)}
                    className="p-2 hover:scale-110 transition-transform"
                  >
                    <Star
                      className={`w-10 h-10 ${
                        star <= rating
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  </button>
                ))}
              </div>
              {rating > 0 && (
                <p className="text-lg font-medium text-[#0075D5]">
                  {getRatingLabel(rating)}
                </p>
              )}
            </div>

            {/* Comment */}
            <div className="mb-8">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Commentaire (optionnel)
              </label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Dites-nous en plus sur votre expérience..."
                rows={4}
                className="input-field resize-none"
              />
            </div>

            {/* Quick Feedback Buttons */}
            <div className="flex justify-center gap-4 mb-8">
              <button
                onClick={() => setRating(5)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg border-2 transition-all ${
                  rating === 5
                    ? 'border-green-500 bg-green-50 text-green-700'
                    : 'border-gray-200 hover:border-green-300'
                }`}
              >
                <ThumbsUp className="w-5 h-5" />
                Excellente
              </button>
              <button
                onClick={() => setRating(2)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg border-2 transition-all ${
                  rating === 2
                    ? 'border-red-500 bg-red-50 text-red-700'
                    : 'border-gray-200 hover:border-red-300'
                }`}
              >
                <ThumbsDown className="w-5 h-5" />
                À améliorer
              </button>
            </div>

            {/* Submit */}
            <div className="flex gap-4">
              <button
                onClick={() => setSelectedComplaint(null)}
                className="flex-1 py-4 border-2 border-gray-200 rounded-lg font-semibold text-gray-600 hover:border-gray-300 transition-colors"
              >
                Plus tard
              </button>
              <button
                onClick={handleSubmitFeedback}
                disabled={isLoading || rating === 0}
                className="flex-1 btn-primary flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Envoyer mon avis
                  </>
                )}
              </button>
            </div>
          </div>
        ) : (
          // List View
          <div className="space-y-6">
            {/* Pending Feedback */}
            <div>
              <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Star className="w-5 h-5 text-yellow-500" />
                En attente d'avis ({resolvedComplaints.length})
              </h2>
              
              {resolvedComplaints.length === 0 ? (
                <div className="bg-white rounded-xl shadow-sm p-8 text-center">
                  <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  </div>
                  <p className="text-gray-600">
                    Vous avez donné votre avis sur toutes vos réclamations résolues.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {resolvedComplaints.map((complaint) => (
                    <div
                      key={complaint.id}
                      className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-all"
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <h3 className="font-semibold text-gray-900 mb-1">{complaint.title}</h3>
                          <p className="text-sm text-gray-500 mb-2">
                            {complaint.department} • Résolue le{' '}
                            {new Date(complaint.resolvedAt!).toLocaleDateString('fr-FR')}
                          </p>
                          <p className="text-sm text-gray-600 line-clamp-2">{complaint.description}</p>
                        </div>
                        <button
                          onClick={() => setSelectedComplaint(complaint)}
                          className="btn-primary whitespace-nowrap"
                        >
                          Donner mon avis
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Given Feedback */}
            {complaintsWithFeedback.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-[#0075D5]" />
                  Avis déjà donnés ({complaintsWithFeedback.length})
                </h2>
                
                <div className="space-y-3">
                  {complaintsWithFeedback.map((complaint) => (
                    <div
                      key={complaint.id}
                      className="bg-white rounded-xl shadow-sm p-6"
                    >
                      <div className="flex items-start justify-between gap-4 mb-4">
                        <div>
                          <h3 className="font-semibold text-gray-900">{complaint.title}</h3>
                          <p className="text-sm text-gray-500">
                            {complaint.department}
                          </p>
                        </div>
                        <div className="flex items-center gap-1 px-3 py-1 bg-green-100 rounded-full">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span className="text-sm text-green-700">Avis donné</span>
                        </div>
                      </div>
                      
                      <div className="bg-gray-50 rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-2">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-5 h-5 ${
                                i < (complaint.feedback?.rating || 0)
                                  ? 'fill-yellow-400 text-yellow-400'
                                  : 'text-gray-300'
                              }`}
                            />
                          ))}
                          <span className="text-sm text-gray-500 ml-2">
                            {new Date(complaint.feedback!.createdAt).toLocaleDateString('fr-FR')}
                          </span>
                        </div>
                        {complaint.feedback?.comment && (
                          <p className="text-gray-700">{complaint.feedback.comment}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
