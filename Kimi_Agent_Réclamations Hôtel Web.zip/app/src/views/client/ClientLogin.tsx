import { useState } from 'react';
import type { View } from '@/types';
import { dataStore } from '@/store/dataStore';
import { 
  ArrowLeft, 
  Mail, 
  Hotel, 
  Loader2,
  MessageSquare
} from 'lucide-react';
import { toast } from 'sonner';

interface ClientLoginProps {
  onNavigate: (view: View) => void;
}

export default function ClientLogin({ onNavigate }: ClientLoginProps) {
  const [email, setEmail] = useState('');
  const [roomNumber, setRoomNumber] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showDemo, setShowDemo] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !roomNumber) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const client = dataStore.loginClient(email, roomNumber);
    
    if (client) {
      toast.success('Connexion réussie !', {
        description: `Bienvenue, ${client.name}`,
      });
      onNavigate('client-dashboard');
    } else {
      // For demo, auto-create a client if not found
      dataStore.registerClient({
        email,
        roomNumber,
        name: email.split('@')[0],
        checkInDate: new Date().toISOString(),
        checkOutDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      });
      toast.success('Bienvenue !', {
        description: `Votre session a été créée pour la chambre ${roomNumber}`,
      });
      onNavigate('client-dashboard');
    }
    
    setIsLoading(false);
  };

  const fillDemoData = () => {
    setEmail('dupont@email.com');
    setRoomNumber('101');
    setShowDemo(false);
  };

  return (
    <div className="min-h-screen gradient-hero flex items-center justify-center p-4">
      {/* Background shapes */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-white/10 rounded-full blur-3xl animate-shape-float-1"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-white/10 rounded-full blur-3xl animate-shape-float-2"></div>
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Back button */}
        <button
          onClick={() => onNavigate('landing')}
          className="absolute -top-16 left-0 flex items-center gap-2 text-white/80 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Retour
        </button>

        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-2xl bg-white flex items-center justify-center mx-auto mb-4 shadow-xl animate-bounce-in">
            <MessageSquare className="w-10 h-10 text-[#0075D5]" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Espace Client</h1>
          <p className="text-white/80">Connectez-vous pour gérer vos réclamations</p>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-2xl shadow-2xl p-8 animate-slide-up">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Adresse email
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="votre@email.com"
                  className="input-field pl-12"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Numéro de chambre
              </label>
              <div className="relative">
                <Hotel className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={roomNumber}
                  onChange={(e) => setRoomNumber(e.target.value)}
                  placeholder="Ex: 101"
                  className="input-field pl-12"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full btn-primary flex items-center justify-center gap-2 disabled:opacity-70"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Connexion...
                </>
              ) : (
                'Se connecter'
              )}
            </button>
          </form>

          {/* Demo hint */}
          <div className="mt-6 pt-6 border-t border-gray-100">
            <button
              onClick={() => setShowDemo(!showDemo)}
              className="text-sm text-[#0075D5] hover:underline w-full text-center"
            >
              Données de démonstration
            </button>
            
            {showDemo && (
              <div className="mt-4 p-4 bg-blue-50 rounded-lg animate-fade-in">
                <p className="text-sm text-gray-600 mb-3">
                  Utilisez ces identifiants pour tester :
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Email:</span>
                    <code className="bg-white px-2 py-0.5 rounded">dupont@email.com</code>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Chambre:</span>
                    <code className="bg-white px-2 py-0.5 rounded">101</code>
                  </div>
                </div>
                <button
                  onClick={fillDemoData}
                  className="mt-3 w-full py-2 text-sm bg-[#0075D5] text-white rounded-lg hover:bg-[#0059A7] transition-colors"
                >
                  Remplir automatiquement
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Admin link */}
        <p className="text-center mt-6 text-white/80 text-sm">
          Vous êtes administrateur ?{' '}
          <button
            onClick={() => onNavigate('admin-login')}
            className="text-white font-semibold hover:underline"
          >
            Connexion Admin
          </button>
        </p>
      </div>
    </div>
  );
}
