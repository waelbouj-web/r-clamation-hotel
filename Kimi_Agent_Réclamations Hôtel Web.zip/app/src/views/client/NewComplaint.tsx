import { useState, useEffect } from 'react';
import type { View, Client, Department } from '@/types';
import { dataStore } from '@/store/dataStore';
import { 
  MessageSquare, 
  ArrowLeft, 
  Send, 
  Loader2,
  Building2,
  CheckCircle,
  AlertTriangle,
  Phone
} from 'lucide-react';
import { toast } from 'sonner';

interface NewComplaintProps {
  onNavigate: (view: View) => void;
}

export default function NewComplaint({ onNavigate }: NewComplaintProps) {
  const [client, setClient] = useState<Client | null>(null);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  // Form state
  const [selectedDept, setSelectedDept] = useState('');
  const [selectedSubDept, setSelectedSubDept] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high' | 'urgent'>('medium');

  useEffect(() => {
    const currentClient = dataStore.getCurrentClient();
    if (!currentClient) {
      toast.error('Veuillez vous connecter');
      onNavigate('client-login');
      return;
    }
    setClient(currentClient);
    setDepartments(dataStore.getAllDepartments().filter(d => d.isActive));
  }, [onNavigate]);

  const selectedDepartment = departments.find(d => d.id === selectedDept);
  const subDepartments = selectedDepartment?.subDepartments.filter(s => s.isActive) || [];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedDept || !selectedSubDept || !title || !description) {
      toast.error('Veuillez remplir tous les champs obligatoires');
      return;
    }

    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    if (client) {
      dataStore.createComplaint({
        clientId: client.id,
        clientName: client.name,
        clientEmail: client.email,
        roomNumber: client.roomNumber,
        department: selectedDepartment?.name || '',
        subDepartment: subDepartments.find(s => s.id === selectedSubDept)?.name || '',
        title,
        description,
        status: 'pending',
        priority,
      });
      
      setIsSuccess(true);
      toast.success('Réclamation soumise avec succès !', {
        description: 'Vous recevrez une notification dès que nous la traiterons.',
      });
    }
    
    setIsLoading(false);
  };

  const handleReset = () => {
    setSelectedDept('');
    setSelectedSubDept('');
    setTitle('');
    setDescription('');
    setPriority('medium');
    setIsSuccess(false);
  };

  if (!client) return null;

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center animate-scale-in">
          <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Réclamation envoyée !
          </h2>
          <p className="text-gray-600 mb-8">
            Votre réclamation a été soumise avec succès. Notre équipe la traitera dans les plus brefs délais.
          </p>
          <div className="space-y-3">
            <button
              onClick={() => onNavigate('client-track')}
              className="w-full btn-primary"
            >
              Suivre mes réclamations
            </button>
            <button
              onClick={handleReset}
              className="w-full btn-secondary"
            >
              Soumettre une autre réclamation
            </button>
            <button
              onClick={() => onNavigate('client-dashboard')}
              className="w-full py-3 text-gray-500 hover:text-gray-700 transition-colors"
            >
              Retour au tableau de bord
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={() => onNavigate('client-dashboard')}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              Retour
            </button>
            <h1 className="text-lg font-bold text-gray-900">Nouvelle réclamation</h1>
            <div className="w-20"></div>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-2xl shadow-sm p-6 sm:p-8 animate-slide-up">
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-xl gradient-hero flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              Soumettre une réclamation
            </h2>
            <p className="text-gray-600">
              Décrivez votre problème et nous le résoudrons rapidement.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Department Selection */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Département <span className="text-red-500">*</span>
                </label>
                <select
                  value={selectedDept}
                  onChange={(e) => {
                    setSelectedDept(e.target.value);
                    setSelectedSubDept('');
                  }}
                  className="input-field"
                  required
                >
                  <option value="">Sélectionner...</option>
                  {departments.map((dept) => (
                    <option key={dept.id} value={dept.id}>
                      {dept.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Type de problème <span className="text-red-500">*</span>
                </label>
                <select
                  value={selectedSubDept}
                  onChange={(e) => setSelectedSubDept(e.target.value)}
                  className="input-field"
                  required
                  disabled={!selectedDept}
                >
                  <option value="">Sélectionner...</option>
                  {subDepartments.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Priority */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Priorité
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { value: 'low', label: 'Basse', color: 'bg-gray-100 text-gray-600 border-gray-200' },
                  { value: 'medium', label: 'Moyenne', color: 'bg-blue-100 text-blue-600 border-blue-200' },
                  { value: 'high', label: 'Haute', color: 'bg-orange-100 text-orange-600 border-orange-200' },
                  { value: 'urgent', label: 'Urgente', color: 'bg-red-100 text-red-600 border-red-200' },
                ].map((p) => (
                  <button
                    key={p.value}
                    type="button"
                    onClick={() => setPriority(p.value as any)}
                    className={`py-3 px-4 rounded-lg border-2 text-sm font-medium transition-all ${
                      priority === p.value
                        ? `${p.color} border-current ring-2 ring-offset-2 ring-current`
                        : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Title */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Titre <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Résumez brièvement votre problème"
                className="input-field"
                required
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description détaillée <span className="text-red-500">*</span>
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Décrivez votre problème en détail..."
                rows={5}
                className="input-field resize-none"
                required
              />
              <p className="mt-2 text-sm text-gray-500">
                Plus vous donnez de détails, plus nous pourrons vous aider rapidement.
              </p>
            </div>

            {/* Room Info */}
            <div className="bg-blue-50 rounded-lg p-4 flex items-start gap-3">
              <Building2 className="w-5 h-5 text-[#0075D5] mt-0.5" />
              <div>
                <p className="text-sm font-medium text-gray-900">
                  Chambre {client.roomNumber}
                </p>
                <p className="text-sm text-gray-600">
                  Cette réclamation sera associée à votre chambre.
                </p>
              </div>
            </div>

            {/* Submit */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button
                type="button"
                onClick={() => onNavigate('client-dashboard')}
                className="sm:flex-1 py-4 px-6 border-2 border-gray-200 rounded-lg font-semibold text-gray-600 hover:border-gray-300 hover:bg-gray-50 transition-all"
              >
                Annuler
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="sm:flex-[2] btn-primary flex items-center justify-center gap-2 disabled:opacity-70"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Envoi en cours...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Soumettre la réclamation
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Info Card */}
        <div className="mt-6 bg-red-50 border border-red-100 rounded-xl p-6 flex items-start gap-4">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-6 h-6 text-red-600" />
          </div>
          <div>
            <h4 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
              Besoin d'assistance urgente ?
            </h4>
            <p className="text-sm text-gray-600 mb-3">
              Pour les problèmes urgents (sécurité, santé), veuillez contacter directement la réception :
            </p>
            <a 
              href="tel:0021672282320" 
              className="inline-flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 transition-colors"
            >
              <Phone className="w-4 h-4" />
              00216 72 282 320
            </a>
          </div>
        </div>
      </main>
    </div>
  );
}
