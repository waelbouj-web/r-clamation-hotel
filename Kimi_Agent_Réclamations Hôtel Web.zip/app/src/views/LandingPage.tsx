import { useEffect, useRef, useState } from 'react';
import type { View } from '@/types';
import { 
  MessageSquare, 
  BarChart3, 
  Smile, 
  Hotel, 
  Clock, 
  CheckCircle, 
  FormInput, 
  Bell, 
  LineChart, 
  Palette, 
  Globe, 
  ChevronLeft, 
  ChevronRight,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  Star,
  Quote
} from 'lucide-react';

interface LandingPageProps {
  onNavigate: (view: View) => void;
}

const features = [
  {
    icon: FormInput,
    title: 'Soumission Facile',
    description: 'Les clients peuvent soumettre leurs réclamations en quelques clics via un formulaire intuitif.',
  },
  {
    icon: BarChart3,
    title: 'Tableau de Bord Admin',
    description: 'Les administrateurs peuvent consulter, filtrer et gérer les réclamations en temps réel.',
  },
  {
    icon: Bell,
    title: 'Notifications en Temps Réel',
    description: 'Recevez des alertes instantanées pour chaque nouvelle réclamation ou mise à jour.',
  },
  {
    icon: LineChart,
    title: 'Analyses et Rapports',
    description: 'Générez des rapports détaillés pour identifier les tendances et améliorer vos services.',
  },
  {
    icon: Palette,
    title: 'Personnalisation',
    description: 'Adaptez l\'application aux couleurs et au branding de votre hôtel.',
  },
  {
    icon: Globe,
    title: 'Support Multilingue',
    description: 'L\'application supporte plusieurs langues pour une expérience utilisateur optimale.',
  },
];

const stats = [
  { number: '500+', label: 'Hôtels partenaires', icon: Hotel },
  { number: '98%', label: 'Taux de satisfaction', icon: Smile },
  { number: '24h', label: 'Temps de réponse moyen', icon: Clock },
  { number: '50K+', label: 'Réclamations gérées', icon: CheckCircle },
];

const testimonials = [
  {
    name: 'Marie Dupont',
    role: 'Directrice, Hôtel Le Grand',
    content: 'Cette application a transformé notre façon de gérer les réclamations. Nous sommes plus réactifs et nos clients sont plus satisfaits.',
    rating: 5,
  },
  {
    name: 'Jean Martin',
    role: 'Gérant, Hôtel Belle Vue',
    content: 'Une solution intuitive et efficace. Elle nous fait gagner un temps précieux au quotidien.',
    rating: 5,
  },
  {
    name: 'Sophie Lefebvre',
    role: 'Responsable, Hôtel Luxe',
    content: 'Les tableaux de bord et les analyses nous aident à identifier les problèmes récurrents et à améliorer nos services.',
    rating: 5,
  },
];

export default function LandingPage({ onNavigate }: LandingPageProps) {
  const [isVisible, setIsVisible] = useState<Record<string, boolean>>({});
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          setIsVisible((prev) => ({
            ...prev,
            [entry.target.id]: entry.isIntersecting,
          }));
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    document.querySelectorAll('[data-animate]').forEach((el) => {
      observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const nextTestimonial = () => {
    setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setActiveTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-lg gradient-hero flex items-center justify-center">
                <MessageSquare className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">Hôtel Réclamation</span>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={() => onNavigate('client-login')}
                className="hidden sm:block px-4 py-2 text-sm font-medium text-gray-700 hover:text-[#0075D5] transition-colors"
              >
                Espace Client
              </button>
              <button
                onClick={() => onNavigate('admin-login')}
                className="btn-primary text-sm"
              >
                Espace Admin
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center gradient-hero pt-16 overflow-hidden">
        {/* Animated background shapes */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-72 h-72 bg-white/10 rounded-full blur-3xl animate-shape-float-1"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-white/10 rounded-full blur-3xl animate-shape-float-2"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-white/5 rounded-full blur-3xl"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h1 
                className={`text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6 transition-all duration-1000 ${
                  isVisible['hero'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
                data-animate
                id="hero"
              >
                Gérez les réclamations de votre hôtel avec{' '}
                <span className="text-[#4BAAFF]">efficacité</span>
              </h1>
              <p 
                className={`text-lg sm:text-xl text-white/90 mb-8 max-w-xl transition-all duration-1000 delay-200 ${
                  isVisible['hero'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
              >
                Une solution complète pour transformer les feedbacks en opportunités d'amélioration
              </p>
              <div 
                className={`flex flex-wrap gap-4 transition-all duration-1000 delay-400 ${
                  isVisible['hero'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
              >
                <button
                  onClick={() => onNavigate('client-login')}
                  className="bg-white text-[#0075D5] px-8 py-4 rounded-lg font-semibold hover:bg-white/90 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl animate-pulse-glow"
                >
                  Commencer gratuitement
                </button>
                <button
                  onClick={() => onNavigate('admin-login')}
                  className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white/10 transition-all duration-300 hover:-translate-y-1"
                >
                  Espace Administrateur
                </button>
              </div>
            </div>

            {/* Hero Cards */}
            <div className="hidden lg:grid grid-cols-2 gap-4">
              {[
                { icon: MessageSquare, title: 'Réclamations en temps réel', delay: 'delay-600' },
                { icon: BarChart3, title: 'Tableaux de bord intuitifs', delay: 'delay-700' },
                { icon: Smile, title: 'Satisfaction client optimisée', delay: 'delay-800' },
              ].map((card, index) => (
                <div
                  key={index}
                  className={`bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20 transition-all duration-700 ${
                    index === 2 ? 'col-span-2' : ''
                  } ${isVisible['hero'] ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'} ${card.delay} hover:bg-white/20 hover:scale-105 hover:-translate-y-2`}
                  style={{ animationDelay: `${600 + index * 100}ms` }}
                >
                  <card.icon className="w-10 h-10 text-white mb-3" />
                  <h3 className="text-white font-semibold">{card.title}</h3>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center pt-2">
            <div className="w-1.5 h-3 bg-white/50 rounded-full"></div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section id="stats" data-animate className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <div
                key={index}
                className={`stat-card text-center transition-all duration-700 ${
                  isVisible['stats'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
                style={{ 
                  transitionDelay: `${200 + index * 150}ms`,
                  transform: isVisible['stats'] 
                    ? `translateZ(${index % 2 === 0 ? 40 : 0}px) translateY(${index % 2 === 0 ? 0 : 20}px)` 
                    : 'translateY(40px)'
                }}
              >
                <stat.icon className="w-8 h-8 mx-auto mb-4 opacity-80" />
                <div className="text-4xl font-bold mb-2 animate-number-glow">{stat.number}</div>
                <div className="text-white/80 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" data-animate className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 
              className={`text-3xl sm:text-4xl font-bold text-gray-900 mb-4 transition-all duration-700 ${
                isVisible['features'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              Fonctionnalités <span className="text-gradient">Clés</span>
            </h2>
            <p 
              className={`text-lg text-gray-600 max-w-2xl mx-auto transition-all duration-700 delay-100 ${
                isVisible['features'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              Tout ce dont vous avez besoin pour gérer les réclamations efficacement
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`card-3d group transition-all duration-700 ${
                  isVisible['features'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-20'
                }`}
                style={{ 
                  transitionDelay: `${400 + index * 100}ms`,
                  transform: isVisible['features'] 
                    ? `translateZ(${index % 2 === 0 ? 40 : 0}px)` 
                    : 'translateY(100px) rotateX(30deg)'
                }}
              >
                <div className="relative overflow-hidden">
                  <div className="w-14 h-14 rounded-xl gradient-hero flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                    <feature.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-[#0075D5] transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" data-animate className="py-20 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 
              className={`text-3xl sm:text-4xl font-bold text-gray-900 mb-4 transition-all duration-700 ${
                isVisible['testimonials'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              Ce que disent nos <span className="text-gradient">clients</span>
            </h2>
          </div>

          <div className="relative max-w-4xl mx-auto">
            <div className="flex items-center justify-center">
              {testimonials.map((testimonial, index) => {
                const isActive = index === activeTestimonial;
                const isPrev = index === (activeTestimonial - 1 + testimonials.length) % testimonials.length;
                const isNext = index === (activeTestimonial + 1) % testimonials.length;

                return (
                  <div
                    key={index}
                    className={`absolute w-full max-w-2xl transition-all duration-600 ${
                      isActive 
                        ? 'opacity-100 scale-100 z-20 translate-x-0' 
                        : isPrev 
                          ? 'opacity-40 scale-90 z-10 -translate-x-[60%] rotate-y-12' 
                          : isNext 
                            ? 'opacity-40 scale-90 z-10 translate-x-[60%] -rotate-y-12'
                            : 'opacity-0 scale-80 z-0'
                    }`}
                    style={{ perspective: '1500px' }}
                  >
                    <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
                      <Quote className="w-12 h-12 text-[#0075D5]/20 mb-4 animate-quote-pulse" />
                      <p className="text-lg text-gray-700 mb-6 italic">"{testimonial.content}"</p>
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 rounded-full gradient-hero flex items-center justify-center text-white text-xl font-bold animate-avatar-glow">
                          {testimonial.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-semibold text-gray-900">{testimonial.name}</div>
                          <div className="text-sm text-gray-500">{testimonial.role}</div>
                          <div className="flex gap-1 mt-1">
                            {[...Array(testimonial.rating)].map((_, i) => (
                              <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Navigation */}
            <div className="flex justify-center gap-4 mt-[400px]">
              <button
                onClick={prevTestimonial}
                className="w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center text-gray-600 hover:text-[#0075D5] hover:scale-110 transition-all duration-300"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <div className="flex gap-2 items-center">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveTestimonial(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === activeTestimonial 
                        ? 'bg-[#0075D5] w-8' 
                        : 'bg-gray-300 hover:bg-gray-400'
                    }`}
                  />
                ))}
              </div>
              <button
                onClick={nextTestimonial}
                className="w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center text-gray-600 hover:text-[#0075D5] hover:scale-110 transition-all duration-300"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="cta" data-animate className="py-20 gradient-cta relative overflow-hidden">
        {/* Background shapes */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-white/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2 animate-shape-float-1"></div>
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-white/10 rounded-full blur-3xl translate-x-1/3 translate-y-1/3 animate-shape-float-2"></div>

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 
            className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 transition-all duration-700 ${
              isVisible['cta'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
          >
            Prêt à transformer la gestion des réclamations de votre hôtel ?
          </h2>
          <p 
            className={`text-xl text-white/90 mb-10 transition-all duration-700 delay-200 ${
              isVisible['cta'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
          >
            Rejoignez plus de 500 hôtels qui font confiance à notre solution.
          </p>
          <button
            onClick={() => onNavigate('client-login')}
            className={`bg-white text-[#0075D5] px-10 py-4 rounded-lg font-semibold text-lg hover:bg-white/90 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl animate-cta-glow ${
              isVisible['cta'] ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
            }`}
            style={{ transitionDelay: '400ms' }}
          >
            Commencer gratuitement
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
            <div className="lg:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-lg gradient-hero flex items-center justify-center">
                  <MessageSquare className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">Hôtel Réclamation</span>
              </div>
              <p className="text-gray-400 mb-4 max-w-sm">
                La solution complète pour gérer les réclamations de votre hôtel avec efficacité et professionnalisme.
              </p>
              <div className="flex gap-4">
                {[Facebook, Twitter, Linkedin, Instagram].map((Icon, index) => (
                  <a
                    key={index}
                    href="#"
                    className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#0075D5] transition-all duration-300 hover:-translate-y-1"
                  >
                    <Icon className="w-5 h-5" />
                  </a>
                ))}
              </div>
            </div>

            {[
              { title: 'Produit', links: ['Fonctionnalités', 'Tarification', 'Intégrations', 'Mises à jour'] },
              { title: 'Ressources', links: ['Blog', 'Guides', 'FAQ', 'Support'] },
              { title: 'Entreprise', links: ['À propos', 'Carrières', 'Contact', 'Partenaires'] },
            ].map((column, index) => (
              <div key={index}>
                <h4 className="font-semibold mb-4">{column.title}</h4>
                <ul className="space-y-2">
                  {column.links.map((link, linkIndex) => (
                    <li key={linkIndex}>
                      <a
                        href="#"
                        className="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition-all duration-300"
                      >
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm">
              © 2024 Hôtel Réclamation. Tous droits réservés.
            </p>
            <div className="flex gap-6 text-sm">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Confidentialité</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Conditions</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Cookies</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
