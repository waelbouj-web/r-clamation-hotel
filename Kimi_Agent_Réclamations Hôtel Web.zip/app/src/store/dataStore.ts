import type { 
  Client, 
  Admin, 
  Complaint, 
  Department, 
  AppConfig, 
  Stats, 
  Notification,
  Feedback,
  Note,
  SubDepartment,
  DailyStat,
  ComplaintStatus
} from '@/types';

// Données initiales
const defaultDepartments: Department[] = [
  {
    id: 'dept-1',
    name: 'Chambre',
    icon: 'Bed',
    isActive: true,
    subDepartments: [
      { id: 'sub-1-1', name: 'Propreté', description: 'Problème de propreté dans la chambre', isActive: true },
      { id: 'sub-1-2', name: 'Équipement défectueux', description: 'TV, climatisation, minibar, etc.', isActive: true },
      { id: 'sub-1-3', name: 'Literie', description: 'Matelas, oreillers, couettes', isActive: true },
      { id: 'sub-1-4', name: 'Bruit', description: 'Problème de nuisance sonore', isActive: true },
      { id: 'sub-1-5', name: 'Température', description: 'Chauffage/climatisation insuffisant', isActive: true },
    ]
  },
  {
    id: 'dept-2',
    name: 'Restauration',
    icon: 'UtensilsCrossed',
    isActive: true,
    subDepartments: [
      { id: 'sub-2-1', name: 'Qualité des repas', description: 'Goût, présentation, fraîcheur', isActive: true },
      { id: 'sub-2-2', name: 'Service lent', description: 'Attente trop longue', isActive: true },
      { id: 'sub-2-3', name: 'Menu restrictif', description: 'Manque de choix/options', isActive: true },
      { id: 'sub-2-4', name: 'Problème de commande', description: 'Erreur ou oubli de commande', isActive: true },
      { id: 'sub-2-5', name: 'Intolérances alimentaires', description: 'Prise en charge des allergies', isActive: true },
    ]
  },
  {
    id: 'dept-3',
    name: 'Réception',
    icon: 'ConciergeBell',
    isActive: true,
    subDepartments: [
      { id: 'sub-3-1', name: 'Check-in/check-out', description: 'Problème lors de l\'arrivée ou départ', isActive: true },
      { id: 'sub-3-2', name: 'Réservation', description: 'Erreur de réservation', isActive: true },
      { id: 'sub-3-3', name: 'Paiement', description: 'Problème de facturation', isActive: true },
      { id: 'sub-3-4', name: 'Informations', description: 'Manque d\'informations', isActive: true },
      { id: 'sub-3-5', name: 'Service client', description: 'Accueil ou attitude du personnel', isActive: true },
    ]
  },
  {
    id: 'dept-4',
    name: 'Spa & Bien-être',
    icon: 'Sparkles',
    isActive: true,
    subDepartments: [
      { id: 'sub-4-1', name: 'Rendez-vous', description: 'Problème de réservation spa', isActive: true },
      { id: 'sub-4-2', name: 'Qualité des soins', description: 'Soins insuffisants', isActive: true },
      { id: 'sub-4-3', name: 'Propreté', description: 'Hygiène des installations', isActive: true },
      { id: 'sub-4-4', name: 'Équipement', description: 'Matériel défectueux', isActive: true },
    ]
  },
  {
    id: 'dept-5',
    name: 'Piscine & Plage',
    icon: 'Waves',
    isActive: true,
    subDepartments: [
      { id: 'sub-5-1', name: 'Propreté', description: 'Eau ou installations sales', isActive: true },
      { id: 'sub-5-2', name: 'Température', description: 'Eau trop froide ou chaude', isActive: true },
      { id: 'sub-5-3', name: 'Transats', description: 'Manque de chaises longues', isActive: true },
      { id: 'sub-5-4', name: 'Serviettes', description: 'Problème de serviettes', isActive: true },
      { id: 'sub-5-5', name: 'Sécurité', description: 'Problème de sécurité', isActive: true },
    ]
  },
  {
    id: 'dept-6',
    name: 'WiFi & Technologie',
    icon: 'Wifi',
    isActive: true,
    subDepartments: [
      { id: 'sub-6-1', name: 'Connexion', description: 'WiFi instable ou lent', isActive: true },
      { id: 'sub-6-2', name: 'Couverture', description: 'Zones sans signal', isActive: true },
      { id: 'sub-6-3', name: 'Authentification', description: 'Problème de connexion', isActive: true },
      { id: 'sub-6-4', name: 'Prises électriques', description: 'Manque de prises', isActive: true },
    ]
  },
  {
    id: 'dept-7',
    name: 'Sécurité',
    icon: 'Shield',
    isActive: true,
    subDepartments: [
      { id: 'sub-7-1', name: 'Coffre-fort', description: 'Problème avec le coffre', isActive: true },
      { id: 'sub-7-2', name: 'Clés/Cartes', description: 'Problème de carte magnétique', isActive: true },
      { id: 'sub-7-3', name: 'Surveillance', description: 'Préoccupations de sécurité', isActive: true },
      { id: 'sub-7-4', name: 'Objets perdus', description: 'Perte ou vol d\'objets', isActive: true },
    ]
  },
  {
    id: 'dept-8',
    name: 'Autre',
    icon: 'MoreHorizontal',
    isActive: true,
    subDepartments: [
      { id: 'sub-8-1', name: 'Général', description: 'Autre type de réclamation', isActive: true },
    ]
  },
];

const defaultAdmins: Admin[] = [
  {
    id: 'admin-1',
    username: 'admin',
    password: 'admin123',
    name: 'Administrateur Principal',
    role: 'superadmin',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'admin-2',
    username: 'manager',
    password: 'manager123',
    name: 'Responsable Hôtel',
    role: 'manager',
    createdAt: new Date().toISOString(),
  },
];

const defaultConfig: AppConfig = {
  hotelName: 'Hôtel Premium',
  primaryColor: '#0075D5',
  secondaryColor: '#0059A7',
  accentColor: '#4BAAFF',
  emailNotifications: true,
  notificationEmail: 'admin@hotel.com',
  smsNotifications: false,
  whatsappNotifications: false,
  whatsappNumber: '',
  autoAssign: true,
  responseTimeHours: 24,
  languages: ['fr', 'en', 'es', 'de'],
  defaultLanguage: 'fr',
};

// Classe pour gérer le store
class DataStore {
  private clients: Client[] = [];
  private admins: Admin[] = [...defaultAdmins];
  private complaints: Complaint[] = [];
  private departments: Department[] = [...defaultDepartments];
  private config: AppConfig = { ...defaultConfig };
  private notifications: Notification[] = [];
  private currentClient: Client | null = null;
  private currentAdmin: Admin | null = null;

  // Client methods
  loginClient(email: string, roomNumber: string): Client | null {
    const client = this.clients.find(
      c => c.email === email && c.roomNumber === roomNumber
    );
    if (client) {
      this.currentClient = client;
      return client;
    }
    return null;
  }

  registerClient(clientData: Omit<Client, 'id'>): Client {
    const newClient: Client = {
      ...clientData,
      id: `client-${Date.now()}`,
    };
    this.clients.push(newClient);
    this.currentClient = newClient;
    return newClient;
  }

  getCurrentClient(): Client | null {
    return this.currentClient;
  }

  logoutClient(): void {
    this.currentClient = null;
  }

  // Admin methods
  loginAdmin(username: string, password: string): Admin | null {
    const admin = this.admins.find(
      a => a.username === username && a.password === password
    );
    if (admin) {
      this.currentAdmin = admin;
      return admin;
    }
    return null;
  }

  getCurrentAdmin(): Admin | null {
    return this.currentAdmin;
  }

  logoutAdmin(): void {
    this.currentAdmin = null;
  }

  createAdmin(adminData: Omit<Admin, 'id'>): Admin {
    const newAdmin: Admin = {
      ...adminData,
      id: `admin-${Date.now()}`,
    };
    this.admins.push(newAdmin);
    return newAdmin;
  }

  deleteAdmin(adminId: string): boolean {
    const index = this.admins.findIndex(a => a.id === adminId);
    if (index > -1) {
      this.admins.splice(index, 1);
      return true;
    }
    return false;
  }

  getAllAdmins(): Admin[] {
    return [...this.admins];
  }

  // Complaint methods
  createComplaint(complaintData: Omit<Complaint, 'id' | 'createdAt' | 'updatedAt' | 'notes' | 'attachments' | 'statusHistory'>): Complaint {
    const now = new Date().toISOString();
    const newComplaint: Complaint = {
      ...complaintData,
      id: `complaint-${Date.now()}`,
      createdAt: now,
      updatedAt: now,
      notes: [],
      attachments: [],
      statusHistory: [
        {
          id: `history-${Date.now()}`,
          status: complaintData.status,
          changedBy: complaintData.clientName,
          changedByRole: 'client',
          changedAt: now,
          note: 'Réclamation créée',
        }
      ],
    };
    this.complaints.push(newComplaint);
    
    // Créer une notification pour les admins
    this.createNotification({
      userId: 'all-admins',
      userType: 'admin',
      title: 'Nouvelle réclamation',
      message: `Une nouvelle réclamation a été soumise par ${complaintData.clientName} (Chambre ${complaintData.roomNumber})`,
      type: 'info',
      link: `/admin/complaints/${newComplaint.id}`,
    });
    
    return newComplaint;
  }

  updateComplaintStatus(complaintId: string, status: ComplaintStatus, changedBy: string, changedByRole: 'client' | 'admin' | 'system' = 'admin', note?: string): Complaint | null {
    const complaint = this.complaints.find(c => c.id === complaintId);
    if (complaint) {
      const oldStatus = complaint.status;
      const now = new Date().toISOString();
      
      complaint.status = status;
      complaint.updatedAt = now;
      
      if (status === 'resolved') {
        complaint.resolvedAt = now;
      }
      
      // Ajouter à l'historique
      complaint.statusHistory.push({
        id: `history-${Date.now()}`,
        status: status,
        changedBy: changedBy,
        changedByRole: changedByRole,
        changedAt: now,
        note: note || `Statut changé de "${this.getStatusLabel(oldStatus)}" à "${this.getStatusLabel(status)}"`,
      });
      
      // Notification au client
      this.createNotification({
        userId: complaint.clientId,
        userType: 'client',
        title: 'Mise à jour de votre réclamation',
        message: `Votre réclamation "${complaint.title}" est maintenant ${this.getStatusLabel(status)}`,
        type: status === 'resolved' ? 'success' : 'info',
      });
      
      return complaint;
    }
    return null;
  }

  addNoteToComplaint(complaintId: string, noteData: Omit<Note, 'id' | 'complaintId' | 'createdAt'>): Note | null {
    const complaint = this.complaints.find(c => c.id === complaintId);
    if (complaint) {
      const newNote: Note = {
        ...noteData,
        id: `note-${Date.now()}`,
        complaintId,
        createdAt: new Date().toISOString(),
      };
      complaint.notes.push(newNote);
      complaint.updatedAt = new Date().toISOString();
      return newNote;
    }
    return null;
  }

  addFeedbackToComplaint(complaintId: string, feedbackData: Omit<Feedback, 'id' | 'complaintId' | 'createdAt'>): Feedback | null {
    const complaint = this.complaints.find(c => c.id === complaintId);
    if (complaint && complaint.status === 'resolved') {
      const newFeedback: Feedback = {
        ...feedbackData,
        id: `feedback-${Date.now()}`,
        complaintId,
        createdAt: new Date().toISOString(),
      };
      complaint.feedback = newFeedback;
      return newFeedback;
    }
    return null;
  }

  getComplaintById(complaintId: string): Complaint | undefined {
    return this.complaints.find(c => c.id === complaintId);
  }

  getComplaintsByClient(clientId: string): Complaint[] {
    return this.complaints.filter(c => c.clientId === clientId);
  }

  getAllComplaints(): Complaint[] {
    return [...this.complaints].sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  getComplaintsByStatus(status: ComplaintStatus): Complaint[] {
    return this.complaints.filter(c => c.status === status);
  }

  // Department methods
  getAllDepartments(): Department[] {
    return [...this.departments];
  }

  getDepartmentById(id: string): Department | undefined {
    return this.departments.find(d => d.id === id);
  }

  createDepartment(deptData: Omit<Department, 'id'>): Department {
    const newDept: Department = {
      ...deptData,
      id: `dept-${Date.now()}`,
    };
    this.departments.push(newDept);
    return newDept;
  }

  updateDepartment(deptId: string, updates: Partial<Department>): Department | null {
    const dept = this.departments.find(d => d.id === deptId);
    if (dept) {
      Object.assign(dept, updates);
      return dept;
    }
    return null;
  }

  deleteDepartment(deptId: string): boolean {
    const index = this.departments.findIndex(d => d.id === deptId);
    if (index > -1) {
      this.departments.splice(index, 1);
      return true;
    }
    return false;
  }

  addSubDepartment(deptId: string, subDeptData: Omit<SubDepartment, 'id'>): SubDepartment | null {
    const dept = this.departments.find(d => d.id === deptId);
    if (dept) {
      const newSubDept: SubDepartment = {
        ...subDeptData,
        id: `sub-${Date.now()}`,
      };
      dept.subDepartments.push(newSubDept);
      return newSubDept;
    }
    return null;
  }

  // Config methods
  getConfig(): AppConfig {
    return { ...this.config };
  }

  updateConfig(updates: Partial<AppConfig>): AppConfig {
    this.config = { ...this.config, ...updates };
    return this.config;
  }

  // Notification methods
  createNotification(notificationData: Omit<Notification, 'id' | 'isRead' | 'createdAt'>): Notification {
    const newNotification: Notification = {
      ...notificationData,
      id: `notif-${Date.now()}`,
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    this.notifications.push(newNotification);
    return newNotification;
  }

  getNotificationsByUser(userId: string, userType: 'client' | 'admin'): Notification[] {
    return this.notifications.filter(
      n => (n.userId === userId || n.userId === `all-${userType}s`) && n.userType === userType
    );
  }

  markNotificationAsRead(notificationId: string): boolean {
    const notification = this.notifications.find(n => n.id === notificationId);
    if (notification) {
      notification.isRead = true;
      return true;
    }
    return false;
  }

  // Statistics methods
  getStats(): Stats {
    const total = this.complaints.length;
    const pending = this.complaints.filter(c => c.status === 'pending').length;
    const inProgress = this.complaints.filter(c => c.status === 'in-progress').length;
    const resolved = this.complaints.filter(c => c.status === 'resolved').length;
    const closed = this.complaints.filter(c => c.status === 'closed').length;

    // Calculer le temps moyen de résolution
    const resolvedComplaints = this.complaints.filter(c => c.resolvedAt);
    const avgResolutionTime = resolvedComplaints.length > 0
      ? resolvedComplaints.reduce((acc, c) => {
          const created = new Date(c.createdAt).getTime();
          const resolved = new Date(c.resolvedAt!).getTime();
          return acc + (resolved - created) / (1000 * 60 * 60); // en heures
        }, 0) / resolvedComplaints.length
      : 0;

    // Calculer le taux de satisfaction
    const complaintsWithFeedback = this.complaints.filter(c => c.feedback);
    const satisfactionRate = complaintsWithFeedback.length > 0
      ? complaintsWithFeedback.reduce((acc, c) => acc + (c.feedback?.rating || 0), 0) / complaintsWithFeedback.length * 20
      : 0;

    // Réclamations par département
    const byDepartment: Record<string, number> = {};
    this.complaints.forEach(c => {
      byDepartment[c.department] = (byDepartment[c.department] || 0) + 1;
    });

    // Réclamations par statut
    const byStatus: Record<string, number> = {
      pending,
      'in-progress': inProgress,
      resolved,
      closed,
    };

    // Réclamations par priorité
    const byPriority: Record<string, number> = {};
    this.complaints.forEach(c => {
      byPriority[c.priority] = (byPriority[c.priority] || 0) + 1;
    });

    // Statistiques journalières (30 derniers jours)
    const dailyStats: DailyStat[] = [];
    for (let i = 29; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const created = this.complaints.filter(c => c.createdAt.startsWith(dateStr)).length;
      const resolved = this.complaints.filter(c => c.resolvedAt?.startsWith(dateStr)).length;
      
      dailyStats.push({ date: dateStr, created, resolved });
    }

    return {
      totalComplaints: total,
      pendingComplaints: pending,
      inProgressComplaints: inProgress,
      resolvedComplaints: resolved,
      closedComplaints: closed,
      averageResolutionTime: Math.round(avgResolutionTime * 10) / 10,
      satisfactionRate: Math.round(satisfactionRate * 10) / 10,
      complaintsByDepartment: byDepartment,
      complaintsByStatus: byStatus,
      complaintsByPriority: byPriority,
      dailyStats,
    };
  }

  // Helper methods
  private getStatusLabel(status: ComplaintStatus): string {
    const labels: Record<ComplaintStatus, string> = {
      pending: 'en attente',
      'in-progress': 'en cours de traitement',
      resolved: 'résolue',
      closed: 'fermée',
    };
    return labels[status];
  }

  // Generate sample data for demo
  generateSampleData(): void {
    // Créer quelques clients de démo
    const demoClients: Client[] = [
      {
        id: 'client-1',
        email: 'dupont@email.com',
        roomNumber: '101',
        name: 'Marie Dupont',
        checkInDate: '2024-01-15',
        checkOutDate: '2024-01-20',
      },
      {
        id: 'client-2',
        email: 'martin@email.com',
        roomNumber: '205',
        name: 'Jean Martin',
        checkInDate: '2024-01-18',
        checkOutDate: '2024-01-25',
      },
      {
        id: 'client-3',
        email: 'lefebvre@email.com',
        roomNumber: '310',
        name: 'Sophie Lefebvre',
        checkInDate: '2024-01-20',
        checkOutDate: '2024-01-27',
      },
    ];

    this.clients = [...demoClients];

    // Créer quelques réclamations de démo
    const demoComplaints: Complaint[] = [
      {
        id: 'complaint-1',
        clientId: 'client-1',
        clientName: 'Marie Dupont',
        clientEmail: 'dupont@email.com',
        roomNumber: '101',
        department: 'Chambre',
        subDepartment: 'Propreté',
        title: 'Chambre mal nettoyée',
        description: 'La salle de bain n\'a pas été correctement nettoyée, il y a des traces de savon dans la douche et les serviettes n\'ont pas été changées.',
        status: 'resolved',
        priority: 'medium',
        createdAt: '2024-01-16T10:30:00Z',
        updatedAt: '2024-01-16T14:00:00Z',
        resolvedAt: '2024-01-16T14:00:00Z',
        assignedTo: 'admin-1',
        notes: [
          {
            id: 'note-1',
            complaintId: 'complaint-1',
            author: 'Administrateur Principal',
            authorRole: 'admin',
            content: 'Le service de ménage a été envoyé immédiatement. La chambre a été nettoyée à nouveau.',
            createdAt: '2024-01-16T11:00:00Z',
          },
        ],
        feedback: {
          id: 'feedback-1',
          complaintId: 'complaint-1',
          rating: 5,
          comment: 'Problème résolu très rapidement, merci !',
          createdAt: '2024-01-16T15:00:00Z',
        },
        attachments: [],
        statusHistory: [
          {
            id: 'history-1-1',
            status: 'pending',
            changedBy: 'Marie Dupont',
            changedByRole: 'client',
            changedAt: '2024-01-16T10:30:00Z',
            note: 'Réclamation créée',
          },
          {
            id: 'history-1-2',
            status: 'in-progress',
            changedBy: 'Administrateur Principal',
            changedByRole: 'admin',
            changedAt: '2024-01-16T10:45:00Z',
            note: 'Statut changé de "En attente" à "En cours"',
          },
          {
            id: 'history-1-3',
            status: 'resolved',
            changedBy: 'Administrateur Principal',
            changedByRole: 'admin',
            changedAt: '2024-01-16T14:00:00Z',
            note: 'Statut changé de "En cours" à "Résolue"',
          },
        ],
      },
      {
        id: 'complaint-2',
        clientId: 'client-2',
        clientName: 'Jean Martin',
        clientEmail: 'martin@email.com',
        roomNumber: '205',
        department: 'Restauration',
        subDepartment: 'Service lent',
        title: 'Attente trop longue au restaurant',
        description: 'Nous avons attendu plus de 45 minutes pour être servis au petit-déjeuner ce matin.',
        status: 'in-progress',
        priority: 'high',
        createdAt: '2024-01-19T08:00:00Z',
        updatedAt: '2024-01-19T09:30:00Z',
        assignedTo: 'admin-2',
        notes: [
          {
            id: 'note-2',
            complaintId: 'complaint-2',
            author: 'Responsable Hôtel',
            authorRole: 'admin',
            content: 'Nous avons pris contact avec le chef de restaurant pour comprendre ce qui s\'est passé.',
            createdAt: '2024-01-19T09:30:00Z',
          },
        ],
        attachments: [],
        statusHistory: [
          {
            id: 'history-2-1',
            status: 'pending',
            changedBy: 'Jean Martin',
            changedByRole: 'client',
            changedAt: '2024-01-19T08:00:00Z',
            note: 'Réclamation créée',
          },
          {
            id: 'history-2-2',
            status: 'in-progress',
            changedBy: 'Responsable Hôtel',
            changedByRole: 'admin',
            changedAt: '2024-01-19T09:30:00Z',
            note: 'Statut changé de "En attente" à "En cours"',
          },
        ],
      },
      {
        id: 'complaint-3',
        clientId: 'client-3',
        clientName: 'Sophie Lefebvre',
        clientEmail: 'lefebvre@email.com',
        roomNumber: '310',
        department: 'WiFi & Technologie',
        subDepartment: 'Connexion',
        title: 'WiFi très lent dans la chambre',
        description: 'La connexion WiFi est presque inexistante dans ma chambre, impossible de travailler.',
        status: 'pending',
        priority: 'high',
        createdAt: '2024-01-21T16:00:00Z',
        updatedAt: '2024-01-21T16:00:00Z',
        notes: [],
        attachments: [],
        statusHistory: [
          {
            id: 'history-3-1',
            status: 'pending',
            changedBy: 'Sophie Lefebvre',
            changedByRole: 'client',
            changedAt: '2024-01-21T16:00:00Z',
            note: 'Réclamation créée',
          },
        ],
      },
    ];

    this.complaints = [...demoComplaints];
  }
}

// Exporter une instance singleton
export const dataStore = new DataStore();
